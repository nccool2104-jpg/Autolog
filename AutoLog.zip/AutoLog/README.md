# AutoLog – personal vehicle fuel and maintenance tracker

Android app (Kotlin, Jetpack Compose). Offline, single user, multi-vehicle.

## Build the APK

1. Install Android Studio (Ladybug or newer, bundled JDK 17+).
2. File > Open > select the `AutoLog` folder. Let Gradle sync (it downloads Gradle 8.7 and dependencies).
   If Studio asks to create the Gradle wrapper, accept.
3. Debug build for testing: Build > Build App Bundle(s) / APK(s) > Build APK(s).
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. Release build for daily use: Build > Generate Signed App Bundle / APK > APK > create a new keystore.
   Store the keystore and its password in your password manager. Losing it means you can't update the app in place.
5. Copy the APK to your phone and install (allow "install unknown apps" for your file manager, then turn it off again).

Run unit tests: right-click `app/src/test` > Run Tests (covers all calculations).

## How the numbers are calculated

| Metric | Method |
|---|---|
| Consumption (L/100 km) | Full-to-full: all litres added after a full tank up to the next full tank, divided by km between them. Partial fills are absorbed. Average is distance-weighted over the last 5 segments. |
| Driving rate (km/day) | Exponentially weighted moving average (alpha 0.3) of km/day between odometer readings from fill-ups and services. |
| Estimated odometer | Last reading + km/day x days since. |
| Fuel left and refill date | Tank capacity + partial fills since last full − km since x L/km. Refill date is when you'd hit a 10% reserve at your current km/day. |
| Maintenance due | Dual trigger: km interval (projected to a date using km/day) or months interval, whichever comes first. Due soon = within 30 days or 1,000 km. |
| Consumption alert | Latest tank more than 15% above the historical baseline (needs 4 segments). |
| Cost per km | Total fuel + service cost / km covered. |

Accuracy depends on logging every fill-up. A missed fill makes that segment look artificially efficient.

## Security design

- No INTERNET permission. The app cannot transmit anything on its own; data leaves only when you share a report.
- Database encrypted with SQLCipher (AES-256). The random key is stored in EncryptedSharedPreferences, protected by the Android Keystore.
- Biometric or device PIN lock on launch (toggle in Reports > Settings). Notification taps cannot bypass it.
- Android cloud backup and device transfer are disabled (the Keystore key can't be restored, so a backup would be unreadable anyway).
- Only the `cache/reports` folder is exposed through FileProvider; old exports are deleted when a new one is built.

## Encrypted backup and restore (Reports tab)

What's included: vehicles, fill-ups, maintenance items, service history, and app settings
(report schedule, recipient, app lock, currency, selected vehicle). Fingerprint data is never included; it is tied to each phone.

**Encryption (envelope).** Each backup gets a random 256-bit data key (AES-256-GCM). That key is locked twice:
- with your password (PBKDF2-HMAC-SHA256, 600,000 iterations), and
- with your recovery key (ECDH P-256 + HKDF-SHA256). The phone holds only the recovery *public* key,
  so it can lock backups for the recovery code but never open them.

The whole header is authenticated, so any modification of the file is detected.

**First backup.** Set a password, then a 56-character recovery code is shown once. You must type its last group to confirm you saved it.
Then you can turn on fingerprint.

**Fingerprint.** The backup password is encrypted with an Android Keystore key that requires a strong (class 3) biometric for every use.
Enrolling a new fingerprint destroys that key automatically; you re-enable with your password.

**Change password.** Requires the current password or fingerprint. Older backup files keep their old password, and still open with the recovery code.

**Forgot password.** Enter the recovery code. The app checks it matches, then lets you set a new password.

**Lost recovery code.** Confirm with your password, and a new code is issued for future backups. Older backups still need the old code or their password.

**Restore.** Pick the file, then unlock with password, fingerprint or recovery code. The app decrypts and validates everything first and shows what's inside.
Choose vehicles/history, settings, or both, then type "restore" to confirm. Data restore is a single database transaction.
On a new phone, the backup's recovery key (and password, if you unlocked with it) are adopted automatically.

## Scheduled reports

WorkManager builds the workbook weekly or monthly and posts a notification. Tap it, the share sheet opens with the file attached and the recipient prefilled; you press send. Android may delay periodic work by a few hours under battery optimisation.

## Adding a vehicle

Garage tab > +. Maintenance items are created from a template based on fuel type (petrol/hybrid add spark plugs, diesel adds fuel filter). Intervals are generic: edit each one to your service manual.
