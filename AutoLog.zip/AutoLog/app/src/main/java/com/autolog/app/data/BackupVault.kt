package com.autolog.app.data

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.autolog.app.domain.BackupCrypto
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Holds the backup configuration on this phone:
 *  - recovery PUBLIC key (can lock backups for the recovery code, cannot open them)
 *  - password verifier (PBKDF2 hash; stops a mistyped password producing an unusable backup)
 *  - optionally, the backup password encrypted with a hardware Keystore key that requires a
 *    strong biometric for every use and is destroyed when a new fingerprint is enrolled.
 */
class BackupVault(private val context: Context, private val store: SecureStore) {

    val isConfigured: Boolean get() = store.recoveryPublicKey != null && store.passwordVerifier != null
    val fingerprintEnabled: Boolean get() = store.fpCiphertext != null
    val recoveryPublicKey: ByteArray? get() = store.recoveryPublicKey

    fun fingerprintAvailable(): Boolean =
        BiometricManager.from(context).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    /** Commit a new password and/or recovery key. Any stored fingerprint copy is cleared (it holds the old password). */
    fun configure(password: CharArray, recoveryPublicKey: ByteArray? = null) {
        store.passwordVerifier = BackupCrypto.makeVerifier(password)
        recoveryPublicKey?.let { store.recoveryPublicKey = it }
        disableFingerprint()
    }

    fun setRecoveryKey(publicKey: ByteArray) { store.recoveryPublicKey = publicKey }

    fun verify(password: CharArray): Boolean = store.passwordVerifier?.let { BackupCrypto.checkVerifier(password, it) } ?: false

    fun disableFingerprint() {
        store.fpCiphertext = null; store.fpIv = null
        runCatching { keystore().deleteEntry(ALIAS) }
    }

    fun enableFingerprint(activity: FragmentActivity, password: CharArray, onDone: (String?) -> Unit) {
        val cipher = try {
            runCatching { keystore().deleteEntry(ALIAS) }
            Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, newKey()) }
        } catch (e: Exception) { password.fill('\u0000'); onDone("Fingerprint could not be set up: ${e.message}"); return }

        prompt(activity, "Use fingerprint for backups", cipher, onError = { password.fill('\u0000'); onDone(it) }) { c ->
            val bytes = toBytes(password)
            try {
                store.fpCiphertext = c.doFinal(bytes); store.fpIv = c.iv
                onDone(null)
            } finally { bytes.fill(0); password.fill('\u0000') }
        }
    }

    /** Biometric prompt, then hands the decrypted password to [onPassword]. Caller must wipe it. */
    fun unlockWithFingerprint(activity: FragmentActivity, onPassword: (CharArray) -> Unit, onError: (String) -> Unit) {
        val ct = store.fpCiphertext; val iv = store.fpIv
        if (ct == null || iv == null) { onError("Fingerprint is not set up"); return }
        val cipher = try {
            val key = keystore().getKey(ALIAS, null) as? SecretKey ?: throw KeyPermanentlyInvalidatedException()
            Cipher.getInstance(TRANSFORM).apply { init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv)) }
        } catch (e: KeyPermanentlyInvalidatedException) {
            disableFingerprint()
            onError("Fingerprints on this phone changed, so fingerprint unlock was turned off. Enter your password, then turn it on again.")
            return
        } catch (e: Exception) { onError("Fingerprint unavailable: ${e.message}"); return }

        prompt(activity, "Unlock backup password", cipher, onError) { c ->
            val bytes = c.doFinal(ct)
            try {
                val chars = Charsets.UTF_8.decode(ByteBuffer.wrap(bytes))
                val out = CharArray(chars.remaining()).also { chars.get(it) }
                onPassword(out)
            } finally { bytes.fill(0) }
        }
    }

    private fun prompt(activity: FragmentActivity, title: String, cipher: Cipher, onError: (String) -> Unit, onOk: (Cipher) -> Unit) {
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher ?: return onError("Fingerprint check failed")
                try { onOk(c) } catch (e: Exception) { onError("Fingerprint check failed: ${e.message}") }
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                if (code != BiometricPrompt.ERROR_NEGATIVE_BUTTON && code != BiometricPrompt.ERROR_USER_CANCELED) onError(msg.toString())
                else onError("")
            }
        }
        BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), callback).authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setAllowedAuthenticators(BIOMETRIC_STRONG)
                .setNegativeButtonText("Use password")
                .build(),
            BiometricPrompt.CryptoObject(cipher),
        )
    }

    private fun newKey(): SecretKey {
        val spec = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
            .apply { if (Build.VERSION.SDK_INT >= 30) setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG) }
            .build()
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(spec) }.generateKey()
    }

    private fun keystore() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun toBytes(chars: CharArray): ByteArray {
        val bb = Charsets.UTF_8.encode(CharBuffer.wrap(chars))
        return ByteArray(bb.remaining()).also { bb.get(it); if (bb.hasArray()) bb.array().fill(0) }
    }

    private companion object {
        const val ALIAS = "autolog_backup_password"
        const val TRANSFORM = "AES/GCM/NoPadding"
    }
}
