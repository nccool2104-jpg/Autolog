package com.autolog.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.autolog.app.data.Vehicle
import com.autolog.app.domain.DueStatus
import com.autolog.app.ui.theme.Palette
import com.autolog.app.ui.theme.Readout
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** Half-dial fuel gauge with an amber needle and a reserve band. */
@Composable
fun FuelGauge(pct: Double?, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val needle = Palette.Amber
    val reserve = Palette.Overdue.copy(alpha = 0.55f)
    val fill = MaterialTheme.colorScheme.primary
    val label = pct?.let { "Fuel ${it.toInt()} percent" } ?: "Fuel level unknown"
    Box(modifier.semantics { contentDescription = label }, contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(2f)) {
            val stroke = size.width * 0.07f
            val d = size.width - stroke
            val topLeft = Offset(stroke / 2, stroke / 2)
            val arc = Size(d, d)
            drawArc(track, 180f, 180f, false, topLeft, arc, style = Stroke(stroke, cap = StrokeCap.Butt))
            drawArc(reserve, 180f, 18f, false, topLeft, arc, style = Stroke(stroke, cap = StrokeCap.Butt))
            if (pct != null) {
                val sweep = (pct.coerceIn(0.0, 100.0) / 100.0 * 180.0).toFloat()
                drawArc(fill, 180f, sweep, false, topLeft, arc, style = Stroke(stroke, cap = StrokeCap.Butt))
                val angle = Math.toRadians(180.0 + sweep)
                val c = Offset(size.width / 2, size.width / 2)
                val r = d / 2 - stroke
                drawLine(needle, c, Offset(c.x + (r * Math.cos(angle)).toFloat(), c.y + (r * Math.sin(angle)).toFloat()), strokeWidth = stroke * 0.35f, cap = StrokeCap.Round)
                drawCircle(needle, stroke * 0.45f, c)
            }
        }
        Text(pct?.let { "${it.toInt()}%" } ?: "—", style = Readout, modifier = Modifier.padding(bottom = 4.dp))
    }
}

@Composable
fun LineChart(values: List<Double>, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.surfaceVariant
    if (values.size < 2) { EmptyHint("Log two full tanks to see the trend", modifier); return }
    Canvas(modifier.fillMaxWidth().height(140.dp)) {
        val min = values.min() * 0.95; val max = values.max() * 1.05
        val span = (max - min).takeIf { it > 0 } ?: 1.0
        repeat(3) { i -> val y = size.height * (i + 1) / 4; drawLine(grid, Offset(0f, y), Offset(size.width, y)) }
        val step = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val p = Offset(i * step, (size.height * (1 - (v - min) / span)).toFloat())
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            drawCircle(color, 4.dp.toPx(), p)
        }
        drawPath(path, color, style = Stroke(2.5.dp.toPx()))
    }
}

@Composable
fun BarChart(values: List<Pair<String, Double>>, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.secondary
    if (values.isEmpty()) { EmptyHint("No spend recorded yet", modifier); return }
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val max = values.maxOf { it.second }.takeIf { it > 0 } ?: 1.0
            val slot = size.width / values.size
            values.forEachIndexed { i, (_, v) ->
                val h = (size.height * v / max).toFloat()
                drawRect(color, Offset(i * slot + slot * 0.2f, size.height - h), Size(slot * 0.6f, h))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            values.forEach { (label, _) ->
                Text(label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), maxLines = 1,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
fun EmptyHint(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(vertical = 16.dp), style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun StatusDot(status: DueStatus) {
    val c = when (status) { DueStatus.OVERDUE -> Palette.Overdue; DueStatus.DUE_SOON -> Palette.Soon; DueStatus.OK -> Palette.Ok }
    Box(Modifier.size(10.dp).background(c, CircleShape))
}

fun statusLabel(s: DueStatus) = when (s) { DueStatus.OVERDUE -> "Overdue"; DueStatus.DUE_SOON -> "Due soon"; DueStatus.OK -> "OK" }

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, suffix: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = { s -> if (s.isEmpty() || s.matches(Regex("""\d*\.?\d*"""))) onChange(s) },
        label = { Text(label) },
        suffix = suffix?.let { { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = modifier.fillMaxWidth(),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, date: LocalDate, onChange: (LocalDate) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = date.toString(), onValueChange = {}, readOnly = true, label = { Text(label) },
        trailingIcon = { IconButton({ open = true }) { Icon(Icons.Default.CalendarMonth, "Pick date") } },
        modifier = Modifier.fillMaxWidth(),
    )
    if (open) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton({
                    state.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                    open = false
                }) { Text("Set date") }
            },
            dismissButton = { TextButton({ open = false }) { Text("Cancel") } },
        ) { DatePicker(state) }
    }
}

@Composable
fun VehiclePicker(vehicles: List<Vehicle>, selected: Vehicle?, onSelect: (Long) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton({ open = true }) {
            Text(selected?.name ?: "No vehicle", style = MaterialTheme.typography.titleMedium)
            Icon(Icons.Default.ArrowDropDown, "Switch vehicle")
        }
        DropdownMenu(open, { open = false }) {
            vehicles.forEach { v ->
                DropdownMenuItem(text = { Text("${v.name}  ${v.plate}") }, onClick = { onSelect(v.id); open = false })
            }
        }
    }
}

fun Double.fmt(d: Int = 0): String = "%,.${d}f".format(this)
