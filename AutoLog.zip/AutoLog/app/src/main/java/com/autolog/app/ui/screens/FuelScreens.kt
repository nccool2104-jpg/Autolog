package com.autolog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.autolog.app.data.FuelEntry
import com.autolog.app.data.Vehicle
import com.autolog.app.ui.components.*
import java.time.LocalDate

@Composable
fun FuelLogScreen(entries: List<FuelEntry>, currency: String, onDelete: (FuelEntry) -> Unit) {
    var confirm by remember { mutableStateOf<FuelEntry?>(null) }
    if (entries.isEmpty()) { EmptyHint("No fill-ups yet. Tap + to log one.", Modifier.padding(16.dp)); return }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(entries, key = { it.id }) { e ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.date}  ·  ${e.odometer.fmt()} km", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${e.litres.fmt(2)} L at $currency ${e.pricePerLitre.fmt(2)}  =  $currency ${e.totalCost.fmt(2)}" +
                                if (e.isFull) "" else "  (partial)",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        if (e.station.isNotBlank()) Text(e.station, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton({ confirm = e }) { Icon(Icons.Outlined.Delete, "Delete fill-up") }
                }
            }
        }
    }
    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete this fill-up?") },
            text = { Text("${e.date}, ${e.litres.fmt(2)} L. Consumption figures will be recalculated. This cannot be undone.") },
            confirmButton = { TextButton({ onDelete(e); confirm = null }) { Text("Delete") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Keep") } },
        )
    }
}

@Composable
fun AddFuelScreen(vehicle: Vehicle, lastOdometer: Double, currency: String, onSave: (FuelEntry) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now()) }
    var odo by remember { mutableStateOf("") }
    var litres by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var full by remember { mutableStateOf(true) }
    var station by remember { mutableStateOf("") }

    // Enter any two of litres / price / total; the third is derived.
    val l = litres.toDoubleOrNull(); val p = price.toDoubleOrNull(); val t = total.toDoubleOrNull()
    val calcTotal = t ?: if (l != null && p != null) l * p else null
    val calcPrice = p ?: if (l != null && t != null && l > 0) t / l else null

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Fill-up for ${vehicle.name}", style = MaterialTheme.typography.titleLarge)
        DateField("Date", date) { date = it }
        NumberField("Odometer", odo, { odo = it }, suffix = "km")
        Text("Last reading ${lastOdometer.fmt()} km", style = MaterialTheme.typography.bodySmall)
        NumberField("Litres", litres, { litres = it }, suffix = "L")
        NumberField("Price per litre", price, { price = it }, suffix = currency)
        NumberField("Total paid", total, { total = it }, suffix = currency)
        if (t == null && calcTotal != null) Text("Total: $currency ${calcTotal.fmt(2)}")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(full, { full = it }); Spacer(Modifier.width(12.dp))
            Column {
                Text("Filled to full")
                Text("Accurate consumption needs every fill-up logged, full or partial.", style = MaterialTheme.typography.bodySmall)
            }
        }
        OutlinedTextField(station, { station = it }, label = { Text("Station (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                onSave(FuelEntry(
                    vehicleId = vehicle.id, date = date, odometer = odo.toDoubleOrNull() ?: -1.0,
                    litres = l ?: 0.0, pricePerLitre = calcPrice ?: 0.0, totalCost = calcTotal ?: 0.0,
                    isFull = full, station = station.trim(),
                ))
            },
            enabled = odo.isNotBlank() && l != null && calcTotal != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save fill-up") }
    }
}
