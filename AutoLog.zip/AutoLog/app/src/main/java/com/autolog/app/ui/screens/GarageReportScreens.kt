package com.autolog.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.autolog.app.data.ReportFrequency
import com.autolog.app.data.Vehicle
import com.autolog.app.domain.FuelType
import com.autolog.app.ui.components.*
import java.time.LocalDate

@Composable
fun GarageScreen(vehicles: List<Vehicle>, selectedId: Long?, onSelect: (Long) -> Unit, onDelete: (Vehicle) -> Unit) {
    var confirm by remember { mutableStateOf<Vehicle?>(null) }
    var typed by remember { mutableStateOf("") }
    if (vehicles.isEmpty()) { EmptyHint("No vehicles yet. Tap + to add one.", Modifier.padding(16.dp)); return }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vehicles, key = { it.id }) { v ->
            Card(Modifier.fillMaxWidth().clickable { onSelect(v.id) }) {
                Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(v.id == selectedId, { onSelect(v.id) })
                    Column(Modifier.weight(1f)) {
                        Text(v.name, style = MaterialTheme.typography.titleSmall)
                        Text(listOfNotNull(v.make, v.model, v.year?.toString(), v.plate).filter { it.isNotBlank() }.joinToString(" "),
                            style = MaterialTheme.typography.bodySmall)
                        Text("${v.fuelType.label}, ${v.tankLitres.fmt()} L tank", style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton({ confirm = v; typed = "" }) { Icon(Icons.Outlined.Delete, "Delete vehicle") }
                }
            }
        }
    }
    // Destructive and cascading: requires typing the vehicle name.
    confirm?.let { v ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete ${v.name}?") },
            text = {
                Column {
                    Text("All fill-ups, maintenance items and service history for this vehicle are permanently deleted. Export a report first if you need a copy.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(typed, { typed = it }, label = { Text("Type ${v.name} to confirm") }, singleLine = true)
                }
            },
            confirmButton = { TextButton({ onDelete(v); confirm = null }, enabled = typed.trim() == v.name) { Text("Delete") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Keep") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddVehicleScreen(onSave: (Vehicle) -> Unit) {
    var name by remember { mutableStateOf("") }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var fuel by remember { mutableStateOf(FuelType.PETROL) }
    var tank by remember { mutableStateOf("") }
    var odo by remember { mutableStateOf("") }
    var since by remember { mutableStateOf(LocalDate.now()) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Add vehicle", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Name, e.g. Daily car") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(make, { make = it }, label = { Text("Make") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Year", year, { year = it.filter(Char::isDigit).take(4) }, Modifier.weight(1f))
            OutlinedTextField(plate, { plate = it.uppercase() }, label = { Text("Plate") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Text("Fuel", style = MaterialTheme.typography.labelLarge)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            FuelType.entries.forEachIndexed { i, t ->
                SegmentedButton(fuel == t, { fuel = t }, SegmentedButtonDefaults.itemShape(i, FuelType.entries.size)) { Text(t.label) }
            }
        }
        NumberField("Tank capacity", tank, { tank = it }, suffix = "L")
        NumberField("Current odometer", odo, { odo = it }, suffix = "km")
        DateField("Tracking from", since) { since = it }
        Text("Maintenance items are pre-filled with generic intervals, counted from this odometer and date. " +
            "If a service was done recently, record it from the Service tab to set the right starting point.",
            style = MaterialTheme.typography.bodySmall)
        Button(
            onClick = {
                onSave(Vehicle(
                    name = name.trim(), make = make.trim(), model = model.trim(), year = year.toIntOrNull(), plate = plate.trim(),
                    fuelType = fuel, tankLitres = tank.toDoubleOrNull() ?: 0.0, initialOdometer = odo.toDoubleOrNull() ?: -1.0,
                    createdOn = since,
                ))
            },
            enabled = name.isNotBlank() && tank.isNotBlank() && odo.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Add vehicle") }
    }
}

@Composable
fun ReportsScreen(
    frequency: ReportFrequency, recipient: String, appLock: Boolean, currency: String,
    onSaveSchedule: (ReportFrequency, String) -> Unit, onExport: () -> Unit,
    onAppLock: (Boolean) -> Unit, onCurrency: (String) -> Unit,
    backupSection: @Composable () -> Unit,
) {
    var freq by remember(frequency) { mutableStateOf(frequency) }
    var email by remember(recipient) { mutableStateOf(recipient) }
    var cur by remember(currency) { mutableStateOf(currency) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Section("Export now") {
            Text("One Excel workbook covering all vehicles: summary, fuel log, consumption, maintenance due, service history and monthly spend.",
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Button(onExport, Modifier.fillMaxWidth()) { Text("Export and email") }
        }
        backupSection()
        Section("Scheduled report") {
            Text("On schedule, the report is built and a notification appears. Tap it to open your mail app with the file attached, then press send.",
                style = MaterialTheme.typography.bodySmall)
            ReportFrequency.entries.forEach { f ->
                Row(Modifier.fillMaxWidth().selectable(freq == f) { freq = f }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(freq == f, { freq = f }); Text(f.label)
                }
            }
            OutlinedTextField(email, { email = it }, label = { Text("Send to") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button({ onSaveSchedule(freq, email) }, Modifier.fillMaxWidth()) { Text("Save schedule") }
        }
        Section("Settings") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Unlock with fingerprint or PIN", Modifier.weight(1f)); Switch(appLock, onAppLock)
            }
            OutlinedTextField(cur, { cur = it.take(4) }, label = { Text("Currency symbol") }, singleLine = true,
                modifier = Modifier.fillMaxWidth())
            TextButton({ onCurrency(cur) }) { Text("Save currency") }
        }
    }
}
