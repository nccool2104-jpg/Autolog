package com.autolog.app.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.security.SecureRandom

@Database(
    entities = [Vehicle::class, FuelEntry::class, MaintenanceItem::class, ServiceRecord::class],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicles(): VehicleDao
    abstract fun fuel(): FuelDao
    abstract fun maintenance(): MaintenanceDao

    companion object {
        fun build(context: Context): AppDatabase {
            System.loadLibrary("sqlcipher")
            val key = SecureStore(context).databaseKey()
            return Room.databaseBuilder(context, AppDatabase::class.java, "autolog.db")
                .openHelperFactory(SupportOpenHelperFactory(key))
                .build()
        }
    }
}

/**
 * Secrets and settings, encrypted with an AES-256 key held in the Android Keystore.
 * The database passphrase is random per install and never leaves the device.
 */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "autolog_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun databaseKey(): ByteArray {
        prefs.getString(KEY_DB, null)?.let { return Base64.decode(it, Base64.NO_WRAP) }
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString(KEY_DB, Base64.encodeToString(bytes, Base64.NO_WRAP)).apply()
        return bytes
    }

    var selectedVehicleId: Long
        get() = prefs.getLong(KEY_VEHICLE, -1L)
        set(v) = prefs.edit().putLong(KEY_VEHICLE, v).apply()

    var reportFrequency: ReportFrequency
        get() = ReportFrequency.valueOf(prefs.getString(KEY_FREQ, ReportFrequency.OFF.name)!!)
        set(v) = prefs.edit().putString(KEY_FREQ, v.name).apply()

    var reportRecipient: String
        get() = prefs.getString(KEY_RECIPIENT, "")!!
        set(v) = prefs.edit().putString(KEY_RECIPIENT, v.trim()).apply()

    var appLock: Boolean
        get() = prefs.getBoolean(KEY_LOCK, true)
        set(v) = prefs.edit().putBoolean(KEY_LOCK, v).apply()

    var currency: String
        get() = prefs.getString(KEY_CURRENCY, "Rs")!!
        set(v) = prefs.edit().putString(KEY_CURRENCY, v.trim()).apply()

    /** Date of the last successful encrypted backup, or null if none was ever made. */
    var lastBackup: java.time.LocalDate?
        get() = prefs.getLong(KEY_LAST_BACKUP, -1L).takeIf { it >= 0 }?.let(java.time.LocalDate::ofEpochDay)
        set(v) = prefs.edit().putLong(KEY_LAST_BACKUP, v?.toEpochDay() ?: -1L).apply()

    var recoveryPublicKey: ByteArray? by bytes("recovery_pub")
    var passwordVerifier: ByteArray? by bytes("pw_verifier")
    var fpCiphertext: ByteArray? by bytes("fp_ct")
    var fpIv: ByteArray? by bytes("fp_iv")

    private fun bytes(key: String) = object : kotlin.properties.ReadWriteProperty<Any?, ByteArray?> {
        override fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>) =
            prefs.getString(key, null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        override fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: ByteArray?) {
            prefs.edit().apply { if (value == null) remove(key) else putString(key, Base64.encodeToString(value, Base64.NO_WRAP)) }.apply()
        }
    }

    private companion object {
        const val KEY_LAST_BACKUP = "last_backup"
        const val KEY_DB = "db_key"
        const val KEY_VEHICLE = "selected_vehicle"
        const val KEY_FREQ = "report_freq"
        const val KEY_RECIPIENT = "report_recipient"
        const val KEY_LOCK = "app_lock"
        const val KEY_CURRENCY = "currency"
    }
}

enum class ReportFrequency(val label: String, val days: Long) {
    OFF("Off", 0), WEEKLY("Weekly", 7), MONTHLY("Monthly", 30)
}
