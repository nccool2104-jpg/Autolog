package com.autolog.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autolog.app.App
import com.autolog.app.data.*
import com.autolog.app.report.ExcelReport
import com.autolog.app.report.ReportWorker
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.net.Uri
import androidx.fragment.app.FragmentActivity
import com.autolog.app.domain.BackupCrypto
import com.autolog.app.domain.BackupException
import com.autolog.app.domain.RecoveryKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as App).repository
    private val backup = (app as App).backup
    private val vault = (app as App).vault
    private val resolver = app.contentResolver
    val store = (app as App).store

    val vehicles = repo.vehicles.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val selectedId = MutableStateFlow(store.selectedVehicleId)

    val selected: StateFlow<Vehicle?> = combine(vehicles, selectedId) { list, id ->
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val fuelEntries = selected.flatMapLatest { v -> v?.let { repo.fuel.observe(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val items = selected.flatMapLatest { v -> v?.let { repo.maintenance.observeItems(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val records = selected.flatMapLatest { v -> v?.let { repo.maintenance.observeRecords(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Recomputed whenever the vehicle or any of its records change. */
    val insights: StateFlow<VehicleInsights?> = combine(selected, fuelEntries, items, records) { v, _, _, _ -> v }
        .mapLatest { v -> v?.let { repo.insights(it) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val message = MutableStateFlow<String?>(null)
    val frequency = MutableStateFlow(store.reportFrequency)
    val recipient = MutableStateFlow(store.reportRecipient)

    fun select(id: Long) { selectedId.value = id; store.selectedVehicleId = id }

    fun addVehicle(v: Vehicle, onDone: () -> Unit) = launchAction("Vehicle added") {
        val id = repo.addVehicle(v); select(id); onDone()
    }

    fun deleteVehicle(v: Vehicle) = launchAction("${v.name} deleted") { repo.vehicles.delete(v) }

    fun addFuel(e: FuelEntry, onDone: () -> Unit) = launchAction("Fill-up saved") {
        val v = selected.value ?: throw ValidationException("Add a vehicle first")
        repo.addFuel(v, e.copy(vehicleId = v.id)); onDone()
    }

    fun deleteFuel(e: FuelEntry) = launchAction("Fill-up deleted") { repo.fuel.delete(e) }

    fun markDone(item: MaintenanceItem, date: LocalDate, odo: Double, cost: Double, note: String, onDone: () -> Unit) =
        run("${item.name} recorded") {
            val v = selected.value ?: return@launchAction
            repo.markServiceDone(v, item, date, odo, cost, note); onDone()
        }

    fun saveItem(item: MaintenanceItem, onDone: () -> Unit) = launchAction("Item saved") {
        if (item.name.isBlank()) throw ValidationException("Enter an item name")
        if (item.intervalKm == null && item.intervalMonths == null) throw ValidationException("Set a km or month interval")
        if (item.id == 0L) repo.maintenance.insertItem(item) else repo.maintenance.updateItem(item)
        onDone()
    }

    fun deleteItem(item: MaintenanceItem) = launchAction("${item.name} removed") { repo.maintenance.deleteItem(item) }

    suspend fun latestOdometer(): Double = selected.value?.let { repo.latestOdometer(it) } ?: 0.0

    fun saveSchedule(freq: ReportFrequency, email: String) {
        if (email.isNotBlank() && !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            message.value = "Enter a valid email address"; return
        }
        store.reportFrequency = freq; store.reportRecipient = email
        frequency.value = freq; recipient.value = email.trim()
        ReportWorker.schedule(getApplication(), freq)
        message.value = if (freq == ReportFrequency.OFF) "Scheduled report turned off" else "${freq.label} report scheduled"
    }

    // --- Settings that the UI observes (restorable from backup) ---

    val currency = MutableStateFlow(store.currency)
    val appLock = MutableStateFlow(store.appLock)
    fun setCurrency(v: String) { store.currency = v; currency.value = store.currency; message.value = "Currency saved" }
    fun setAppLock(v: Boolean) { store.appLock = v; appLock.value = v }

    // --- Encrypted backup ---

    val busy = MutableStateFlow<String?>(null)
    val lastBackup = MutableStateFlow(store.lastBackup)
    val backupConfigured = MutableStateFlow(vault.isConfigured)
    val fingerprintEnabled = MutableStateFlow(vault.fingerprintEnabled)
    val hasRecoveryKey get() = vault.recoveryPublicKey != null
    val fingerprintAvailable get() = vault.fingerprintAvailable()

    class RestorePreview(val contents: BackupContents, val password: CharArray?)
    val restorePreview = MutableStateFlow<RestorePreview?>(null)

    private fun refreshVault() { backupConfigured.value = vault.isConfigured; fingerprintEnabled.value = vault.fingerprintEnabled }

    fun newRecoveryKey(): RecoveryKey = BackupCrypto.newRecoveryKey()

    /** First-time setup, or password-only setup when a recovery key was adopted from a restored backup. */
    fun commitSetup(password: CharArray, key: RecoveryKey?, onDone: () -> Unit) = withBusy("Securing backup settings…") {
        vault.configure(password, key?.publicKey); refreshVault(); main { onDone() }
    }

    fun checkPassword(password: CharArray, onOk: () -> Unit) = withBusy("Checking password…") {
        if (vault.verify(password)) main { onOk() } else { password.fill('\u0000'); message.value = "Incorrect backup password" }
    }

    /** Recovery code holder proves ownership before a forgotten password can be reset. */
    fun checkRecovery(code: String, onOk: () -> Unit) = withBusy("Checking recovery code…") {
        val pub = vault.recoveryPublicKey ?: throw BackupException("No recovery key is set up on this phone")
        if (BackupCrypto.recoveryMatches(code, pub)) main { onOk() } else message.value = "Recovery code doesn't match this phone's backups"
    }

    fun changePassword(newPassword: CharArray, onDone: () -> Unit) = withBusy("Saving new password…") {
        vault.configure(newPassword); refreshVault()
        message.value = "Backup password changed. Older backups still open with the old password or your recovery code."
        main { onDone() }
    }

    fun rotateRecovery(key: RecoveryKey) {
        vault.setRecoveryKey(key.publicKey)
        message.value = "New recovery code active for future backups. Keep the old one for older backups."
    }

    fun enableFingerprint(activity: FragmentActivity, password: CharArray, onDone: () -> Unit = {}) =
        vault.enableFingerprint(activity, password) { err ->
            refreshVault()
            message.value = err?.takeIf { it.isNotBlank() } ?: if (err == null) "Fingerprint turned on for backups" else null
            onDone()
        }

    fun disableFingerprint() { vault.disableFingerprint(); refreshVault(); message.value = "Fingerprint turned off for backups" }

    fun unlockWithFingerprint(activity: FragmentActivity, onPassword: (CharArray) -> Unit, onFallback: () -> Unit) =
        vault.unlockWithFingerprint(activity, onPassword) { err -> refreshVault(); if (err.isNotBlank()) message.value = err; onFallback() }

    fun createBackup(uri: Uri, password: CharArray) = withBusy("Encrypting backup…") {
        try {
            val pub = vault.recoveryPublicKey ?: throw BackupException("Set up backup protection first")
            val blob = backup.export(password, pub, currentSettings())
            val out = resolver.openOutputStream(uri, "wt") ?: throw BackupException("Could not open the chosen location")
            out.use { it.write(blob) }
            store.lastBackup = LocalDate.now(); lastBackup.value = store.lastBackup
            message.value = "Encrypted backup saved, including settings"
        } finally { password.fill('\u0000') }
    }

    /** Step 1 of restore: decrypt and validate only. Nothing changes until confirmRestore(). */
    fun previewRestore(uri: Uri, secret: BackupManager.Secret) = withBusy("Decrypting backup…") {
        try {
            val size = resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
            if (size > MAX_BACKUP_BYTES) throw BackupException("File is too large to be an AutoLog backup")
            val blob = resolver.openInputStream(uri)?.use { it.readBytes() } ?: throw BackupException("Could not read the file")
            val c = backup.read(blob, secret)
            restorePreview.value = RestorePreview(c, (secret as? BackupManager.Secret.Password)?.chars?.copyOf())
        } finally { (secret as? BackupManager.Secret.Password)?.chars?.fill('\u0000') }
    }

    fun confirmRestore(restoreData: Boolean, restoreSettings: Boolean) = withBusy("Restoring…") {
        val p = restorePreview.value ?: return@withBusy
        val c = p.contents
        try {
            if (restoreData) backup.restore(c)
            if (restoreSettings) c.settings?.let { applySettings(it) }
            // New phone: adopt the backup's recovery key, and its password if that's how it was opened.
            if (!vault.isConfigured && c.recoveryPublicKey != null) {
                vault.setRecoveryKey(c.recoveryPublicKey)
                p.password?.let { vault.configure(it) }
                refreshVault()
            }
            if (restoreData) (c.settings?.selectedVehicleId?.takeIf { id -> c.vehicles.any { it.id == id } }
                ?: c.vehicles.firstOrNull()?.id)?.let { main { select(it) } }
            message.value = listOfNotNull(
                if (restoreData) "${c.vehicles.size} vehicle(s)" else null,
                if (restoreSettings && c.settings != null) "settings" else null,
            ).joinToString(" and ", prefix = "Restored ")
        } finally {
            p.password?.fill('\u0000'); restorePreview.value = null
        }
    }

    fun cancelRestore() { restorePreview.value?.password?.fill('\u0000'); restorePreview.value = null }

    private fun currentSettings() = BackupSettings(store.reportFrequency, store.reportRecipient, store.appLock, store.currency, store.selectedVehicleId)

    private suspend fun applySettings(s: BackupSettings) = main {
        store.reportFrequency = s.reportFrequency; frequency.value = s.reportFrequency
        store.reportRecipient = s.reportRecipient; recipient.value = s.reportRecipient
        setAppLock(s.appLock)
        store.currency = s.currency; currency.value = s.currency
        ReportWorker.schedule(getApplication(), s.reportFrequency)
    }

    private suspend fun main(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun withBusy(label: String, block: suspend () -> Unit) {
        if (busy.value != null) return
        viewModelScope.launch {
            busy.value = label
            try { withContext(Dispatchers.IO) { block() } }
            catch (e: BackupException) { message.value = e.message }
            catch (e: Exception) { message.value = "Backup failed: ${e.message}" }
            finally { busy.value = null }
        }
    }

    fun exportNow(onReady: (File) -> Unit) = launchAction(null) { onReady(ExcelReport.build(getApplication())) }

    private fun launchAction(success: String?, block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block(); success?.let { message.value = it } }
            catch (e: ValidationException) { message.value = e.message }
            catch (e: Exception) { message.value = "Something went wrong: ${e.message}" }
        }
    }

    private companion object { const val MAX_BACKUP_BYTES = 50L * 1024 * 1024 }
}
