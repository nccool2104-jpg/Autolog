package com.autolog.app.ui.screens

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.FragmentActivity
import com.autolog.app.data.BackupManager
import com.autolog.app.domain.BackupCrypto
import com.autolog.app.domain.RecoveryKey
import com.autolog.app.ui.AppViewModel
import com.autolog.app.ui.theme.Palette
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

internal enum class AuthFor { BACKUP, CHANGE, ROTATE, FINGERPRINT }

internal sealed interface Step {
    data object None : Step
    /** Set a new password. passwordOnly: a recovery key already exists (adopted from a restore). */
    data class Setup(val passwordOnly: Boolean) : Step
    data class ShowCode(val key: RecoveryKey, val password: CharArray?, val rotate: Boolean) : Step
    data class OfferFingerprint(val password: CharArray, val thenBackup: Boolean) : Step
    data class Auth(val purpose: AuthFor) : Step
    data class NewPassword(val reset: Boolean) : Step
    data object EnterRecovery : Step
    data class Unlock(val uri: Uri, val recovery: Boolean) : Step
}

/** Owns every backup dialog and the order they appear in. ReportsScreen only calls its entry points. */
class BackupFlow internal constructor() {
    internal var step by mutableStateOf<Step>(Step.None)
    internal lateinit var startCreate: () -> Unit
    internal lateinit var startRestore: () -> Unit
    fun create() = startCreate()
    fun restore() = startRestore()
    fun changePassword() { step = Step.Auth(AuthFor.CHANGE) }
    fun forgotPassword() { step = Step.EnterRecovery }
    fun newRecoveryCode() { step = Step.Auth(AuthFor.ROTATE) }
    fun enableFingerprint() { step = Step.Auth(AuthFor.FINGERPRINT) }
}

@Composable
fun rememberBackupFlow(vm: AppViewModel): BackupFlow {
    val flow = remember { BackupFlow() }
    val activity = LocalContext.current as FragmentActivity
    val configured by vm.backupConfigured.collectAsState()
    val fingerprintOn by vm.fingerprintEnabled.collectAsState()
    val preview by vm.restorePreview.collectAsState()
    var held by remember { mutableStateOf<CharArray?>(null) } // password waiting for the file picker

    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pw = held; held = null
        if (uri != null && pw != null) vm.createBackup(uri, pw) else pw?.fill('\u0000')
    }
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) flow.step = Step.Unlock(uri, recovery = false)
    }

    fun backupWith(pw: CharArray) { held = pw; createDoc.launch("AutoLog_backup_${LocalDate.now()}.albk") }

    /** After a password is set: offer fingerprint, then continue to the backup if that's what started it. */
    fun afterPasswordSet(pw: CharArray, thenBackup: Boolean) {
        flow.step = when {
            vm.fingerprintAvailable -> Step.OfferFingerprint(pw, thenBackup)
            thenBackup -> { backupWith(pw); Step.None }
            else -> { pw.fill('\u0000'); Step.None }
        }
    }

    flow.startCreate = { flow.step = if (configured) Step.Auth(AuthFor.BACKUP) else Step.Setup(passwordOnly = vm.hasRecoveryKey) }
    flow.startRestore = { openDoc.launch(arrayOf("*/*")) }

    fun onAuthenticated(purpose: AuthFor, pw: CharArray) {
        when (purpose) {
            AuthFor.BACKUP -> { flow.step = Step.None; backupWith(pw) }
            AuthFor.CHANGE -> { pw.fill('\u0000'); flow.step = Step.NewPassword(reset = false) }
            AuthFor.ROTATE -> { pw.fill('\u0000'); flow.step = Step.ShowCode(vm.newRecoveryKey(), null, rotate = true) }
            AuthFor.FINGERPRINT -> { flow.step = Step.None; vm.enableFingerprint(activity, pw) }
        }
    }

    when (val s = flow.step) {
        Step.None -> {}
        is Step.Setup -> PasswordDialog(
            creating = true, title = "Set backup password",
            onDismiss = { flow.step = Step.None },
        ) { pw ->
            if (s.passwordOnly) vm.commitSetup(pw, null) { afterPasswordSet(pw, thenBackup = true) }
            else flow.step = Step.ShowCode(vm.newRecoveryKey(), pw, rotate = false)
        }
        is Step.ShowCode -> RecoveryCodeDialog(s.key.code, onDismiss = { s.password?.fill('\u0000'); flow.step = Step.None }) {
            if (s.rotate) { vm.rotateRecovery(s.key); flow.step = Step.None }
            else s.password?.let { pw -> vm.commitSetup(pw, s.key) { afterPasswordSet(pw, thenBackup = true) } }
        }
        is Step.OfferFingerprint -> AlertDialog(
            onDismissRequest = {},
            icon = { Icon(Icons.Outlined.Fingerprint, null) },
            title = { Text("Use fingerprint for backups?") },
            text = { Text("Unlock the backup password with your fingerprint instead of typing it. Adding a new fingerprint to the phone turns this off automatically.") },
            confirmButton = {
                TextButton({
                    flow.step = Step.None
                    vm.enableFingerprint(activity, s.password.copyOf()) {
                        if (s.thenBackup) backupWith(s.password) else s.password.fill('\u0000')
                    }
                }) { Text("Use fingerprint") }
            },
            dismissButton = {
                TextButton({ flow.step = Step.None; if (s.thenBackup) backupWith(s.password) else s.password.fill('\u0000') }) { Text("Not now") }
            },
        )
        is Step.Auth -> {
            val allowFp = fingerprintOn && s.purpose != AuthFor.FINGERPRINT
            val tryFp = { vm.unlockWithFingerprint(activity, { onAuthenticated(s.purpose, it) }, onFallback = {}) }
            LaunchedEffect(s) { if (allowFp) tryFp() }
            PasswordDialog(
                creating = false,
                title = when (s.purpose) {
                    AuthFor.BACKUP -> "Backup password"; AuthFor.CHANGE -> "Current backup password"
                    AuthFor.ROTATE -> "Confirm backup password"; AuthFor.FINGERPRINT -> "Enter password to link fingerprint"
                },
                onDismiss = { flow.step = Step.None },
                onFingerprint = if (allowFp) tryFp else null,
                onForgot = if (s.purpose != AuthFor.FINGERPRINT) ({ flow.step = Step.EnterRecovery }) else null,
            ) { pw -> vm.checkPassword(pw) { onAuthenticated(s.purpose, pw) } }
        }
        is Step.NewPassword -> PasswordDialog(
            creating = true, title = if (s.reset) "Set a new backup password" else "New backup password",
            onDismiss = { flow.step = Step.None },
        ) { pw ->
            val hadFingerprint = fingerprintOn
            vm.changePassword(pw) { if (hadFingerprint || s.reset) afterPasswordSet(pw, thenBackup = false) else { pw.fill('\u0000'); flow.step = Step.None } }
        }
        Step.EnterRecovery -> RecoveryEntryDialog(
            text = "Enter your recovery code to set a new password. Backups made with the old password still open with this recovery code.",
            onDismiss = { flow.step = Step.None },
        ) { code -> vm.checkRecovery(code) { flow.step = Step.NewPassword(reset = true) } }
        is Step.Unlock -> {
            if (s.recovery) RecoveryEntryDialog(
                text = "Enter the recovery code that was active when this backup was made.",
                onDismiss = { flow.step = Step.None },
            ) { code -> vm.previewRestore(s.uri, BackupManager.Secret.Recovery(code)) }
            else {
                val tryFp = {
                    vm.unlockWithFingerprint(activity, { pw -> vm.previewRestore(s.uri, BackupManager.Secret.Password(pw)) }, onFallback = {})
                }
                PasswordDialog(
                    creating = false, title = "Unlock backup",
                    onDismiss = { flow.step = Step.None },
                    onFingerprint = if (fingerprintOn) tryFp else null,
                    onForgot = { flow.step = s.copy(recovery = true) },
                    forgotLabel = "Use recovery code",
                ) { pw -> vm.previewRestore(s.uri, BackupManager.Secret.Password(pw)) }
            }
        }
    }

    // Keep the unlock dialog open until decryption succeeds, so a wrong password can simply be retried.
    LaunchedEffect(preview) { if (preview != null && flow.step is Step.Unlock) flow.step = Step.None }
    preview?.let { p -> RestoreConfirmDialog(p, vm.vehicles.collectAsState().value.size, vm::confirmRestore, vm::cancelRestore) }
    vm.busy.collectAsState().value?.let { BusyDialog(it) }
    return flow
}

// ---------------- UI pieces ----------------

@Composable
fun BackupSection(vm: AppViewModel, flow: BackupFlow) {
    val lastBackup by vm.lastBackup.collectAsState()
    val configured by vm.backupConfigured.collectAsState()
    val fingerprintOn by vm.fingerprintEnabled.collectAsState()
    Section("Encrypted backup") {
        val age = lastBackup?.let { ChronoUnit.DAYS.between(it, LocalDate.now()) }
        Text(
            when {
                lastBackup == null -> "No backup yet. Your data exists only on this phone."
                age!! == 0L -> "Last backup: today."
                else -> "Last backup: $lastBackup ($age days ago)."
            },
            color = if (age == null || age > 30) Palette.Overdue else MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(4.dp))
        Text("Includes vehicles, history and app settings, encrypted with AES-256. Opens with your password or your recovery code. " +
            "Save it off this phone, such as Google Drive or a computer.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Button(flow::create, Modifier.fillMaxWidth()) { Text(if (configured) "Create backup" else "Set up and create backup") }
        OutlinedButton(flow::restore, Modifier.fillMaxWidth()) { Text("Restore from backup") }

        if (configured) {
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            if (vm.fingerprintAvailable) Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Unlock with fingerprint")
                    Text("Instead of typing the backup password", style = MaterialTheme.typography.bodySmall)
                }
                Switch(fingerprintOn, { on -> if (on) flow.enableFingerprint() else vm.disableFingerprint() })
            }
            TextButton(flow::changePassword) { Text("Change password") }
            TextButton(flow::forgotPassword) { Text("Forgot password? Reset with recovery code") }
            TextButton(flow::newRecoveryCode) { Text("Lost recovery code? Create a new one") }
        }
    }
}

@Composable
private fun PasswordDialog(
    creating: Boolean, title: String, onDismiss: () -> Unit,
    onFingerprint: (() -> Unit)? = null, onForgot: (() -> Unit)? = null, forgotLabel: String = "Forgot password?",
    onSubmit: (CharArray) -> Unit,
) {
    var pw by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    val tooShort = creating && pw.length < BackupCrypto.MIN_PASSWORD
    val mismatch = creating && confirm.isNotEmpty() && confirm != pw
    val ok = pw.isNotEmpty() && !tooShort && (!creating || confirm == pw)

    AlertDialog(
        onDismissRequest = { pw = ""; confirm = ""; onDismiss() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PasswordField("Password", pw, show, { pw = it }) { show = !show }
                if (creating) {
                    PasswordField("Repeat password", confirm, show, { confirm = it }) { show = !show }
                    Text(
                        when {
                            tooShort -> "At least ${BackupCrypto.MIN_PASSWORD} characters. Four random words work well."
                            mismatch -> "Passwords don't match."
                            else -> "Store it in your password manager."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (mismatch) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (onFingerprint != null) OutlinedButton(onFingerprint, Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text("Use fingerprint")
                }
                if (onForgot != null) TextButton(onForgot) { Text(forgotLabel) }
            }
        },
        confirmButton = { TextButton({ val c = pw.toCharArray(); pw = ""; confirm = ""; onSubmit(c) }, enabled = ok) { Text("Continue") } },
        dismissButton = { TextButton({ pw = ""; confirm = ""; onDismiss() }) { Text("Cancel") } },
    )
}

@Composable
private fun PasswordField(label: String, value: String, show: Boolean, onChange: (String) -> Unit, onToggle: () -> Unit) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false,
            capitalization = KeyboardCapitalization.None),
        trailingIcon = {
            IconButton(onToggle) {
                Icon(if (show) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, if (show) "Hide password" else "Show password")
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Shown once. The user must re-type the last group to prove the code was recorded. */
@Composable
private fun RecoveryCodeDialog(code: String, onDismiss: () -> Unit, onConfirmed: () -> Unit) {
    val context = LocalContext.current
    val groups = code.split("-")
    var check by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnClickOutside = false),
        title = { Text("Your recovery code") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("If you forget your backup password, this code is the only way to open your backups. " +
                    "It is shown once and not stored on this phone. Write it down or save it in your password manager.")
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(
                        groups.chunked(4).joinToString("\n") { it.joinToString("  ") },
                        Modifier.padding(12.dp).fillMaxWidth(),
                        fontFamily = FontFamily.Monospace, fontSize = 17.sp, lineHeight = 26.sp,
                    )
                }
                TextButton({ copySensitive(context, code) }) { Text("Copy to clipboard") }
                OutlinedTextField(check, { check = it.uppercase() }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Type the last group (${groups.size}) to confirm") })
            }
        },
        confirmButton = { TextButton(onConfirmed, enabled = check.trim() == groups.last()) { Text("I've saved it") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

private fun copySensitive(context: Context, text: String) {
    val clip = ClipData.newPlainText("Recovery code", text)
    // Android 13+: hide the content from the clipboard preview and keyboard suggestions.
    if (Build.VERSION.SDK_INT >= 33) clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
    context.getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
}

@Composable
private fun RecoveryEntryDialog(text: String, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    val chars = code.count { it.isLetterOrDigit() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recovery code") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(code, { code = it.uppercase() }, label = { Text("Recovery code") }, minLines = 3,
                    keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, capitalization = KeyboardCapitalization.Characters),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace), modifier = Modifier.fillMaxWidth())
                Text("$chars of 56 characters. Dashes and spaces are optional.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton({ onSubmit(code) }, enabled = chars == 56) { Text("Continue") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

/** Restore replaces data, so it shows exactly what changes, lets you choose, and needs a typed confirmation. */
@Composable
private fun RestoreConfirmDialog(
    p: AppViewModel.RestorePreview, currentVehicles: Int,
    onConfirm: (Boolean, Boolean) -> Unit, onDismiss: () -> Unit,
) {
    val c = p.contents
    var data by remember { mutableStateOf(true) }
    var settings by remember { mutableStateOf(c.settings != null) }
    var typed by remember { mutableStateOf("") }
    val stamp = c.exportedAt.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Restore backup from $stamp") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(data, { data = it })
                    Text("Vehicles and history: ${c.vehicles.size} vehicle(s), ${c.fuel.size} fill-ups, ${c.records.size} services")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(settings, { settings = it }, enabled = c.settings != null)
                    Text(c.settings?.let { "Settings: ${it.reportFrequency.label.lowercase()} report, currency ${it.currency}, app lock ${if (it.appLock) "on" else "off"}" }
                        ?: "Settings: not in this backup")
                }
                if (data) Text("Your current vehicles and history ($currentVehicles vehicle(s)) will be permanently replaced. " +
                    "Create a backup first if you may need them.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Fingerprint unlock is tied to each phone and is never restored; turn it on again afterwards.",
                    style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(typed, { typed = it }, label = { Text("Type restore to confirm") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton({ onConfirm(data, settings) }, enabled = (data || settings) && typed.trim().equals("restore", true)) { Text("Restore") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun BusyDialog(label: String) {
    Dialog({}, DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
        Card {
            Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text(label)
            }
        }
    }
}
