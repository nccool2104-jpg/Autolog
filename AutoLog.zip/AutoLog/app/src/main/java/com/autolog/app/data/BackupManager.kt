package com.autolog.app.data

import androidx.room.withTransaction
import com.autolog.app.domain.BackupCrypto
import com.autolog.app.domain.BackupException
import com.autolog.app.domain.FuelType
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.Base64
import java.time.LocalDate

/** Fully parsed, validated backup held in memory until the user confirms the restore. */
/** App settings carried in the backup. Device-bound secrets (Keystore keys, fingerprint data) are never included. */
data class BackupSettings(
    val reportFrequency: ReportFrequency,
    val reportRecipient: String,
    val appLock: Boolean,
    val currency: String,
    val selectedVehicleId: Long,
)

class BackupContents(
    val exportedAt: Instant,
    val settings: BackupSettings?,
    val recoveryPublicKey: ByteArray?,
    val vehicles: List<Vehicle>,
    val fuel: List<FuelEntry>,
    val items: List<MaintenanceItem>,
    val records: List<ServiceRecord>,
)

class BackupManager(private val db: AppDatabase) {

    suspend fun export(password: CharArray, recoveryPublicKey: ByteArray, settings: BackupSettings): ByteArray {
        val json = JSONObject()
            .put("schema", SCHEMA)
            .put("exportedAt", Instant.now().toString())
            .put("settings", settingsJson(settings))
            .put("recoveryPublicKey", Base64.getEncoder().encodeToString(recoveryPublicKey))
            .put("vehicles", JSONArray(db.vehicles().all().map(::vehicleJson)))
            .put("fuel", JSONArray(db.fuel().all().map(::fuelJson)))
            .put("items", JSONArray(db.maintenance().allItems().map(::itemJson)))
            .put("records", JSONArray(db.maintenance().allRecords().map(::recordJson)))
        val plain = json.toString().toByteArray(Charsets.UTF_8)
        return try { BackupCrypto.encrypt(plain, password, recoveryPublicKey) } finally { plain.fill(0) }
    }

    sealed interface Secret {
        class Password(val chars: CharArray) : Secret
        class Recovery(val code: String) : Secret
    }

    /** Decrypts and validates. Touches nothing in the database or settings. */
    fun read(blob: ByteArray, secret: Secret): BackupContents {
        val plain = when (secret) {
            is Secret.Password -> BackupCrypto.decryptWithPassword(blob, secret.chars)
            is Secret.Recovery -> BackupCrypto.decryptWithRecovery(blob, secret.code)
        }
        try {
            val j = JSONObject(String(plain, Charsets.UTF_8))
            val schema = j.getInt("schema")
            if (schema > SCHEMA) throw BackupException("This backup was made by a newer app version. Update AutoLog first.")
            val c = BackupContents(
                exportedAt = Instant.parse(j.getString("exportedAt")),
                settings = j.optJSONObject("settings")?.let(::settings),
                recoveryPublicKey = j.optString("recoveryPublicKey").takeIf { it.isNotEmpty() }?.let { Base64.getDecoder().decode(it) },
                vehicles = j.getJSONArray("vehicles").objects().map(::vehicle),
                fuel = j.getJSONArray("fuel").objects().map(::fuel),
                items = j.getJSONArray("items").objects().map(::item),
                records = j.getJSONArray("records").objects().map(::record),
            )
            val ids = c.vehicles.map { it.id }.toSet()
            if (ids.size != c.vehicles.size ||
                (c.fuel.map { it.vehicleId } + c.items.map { it.vehicleId } + c.records.map { it.vehicleId }).any { it !in ids }
            ) throw BackupException("Backup content is inconsistent; nothing was restored")
            return c
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException("Backup content could not be read; nothing was restored")
        } finally {
            plain.fill(0)
        }
    }

    /** Replaces all vehicle data in one transaction: either everything is restored or nothing changes. */
    suspend fun restore(c: BackupContents) = db.withTransaction {
        db.maintenance().deleteAllRecords()
        db.maintenance().deleteAllItems()
        db.fuel().deleteAll()
        db.vehicles().deleteAll()
        db.vehicles().insertAll(c.vehicles)
        db.fuel().insertAll(c.fuel)
        db.maintenance().insertItems(c.items)
        db.maintenance().insertRecords(c.records)
    }

    private fun settingsJson(s: BackupSettings) = JSONObject().put("reportFrequency", s.reportFrequency.name)
        .put("reportRecipient", s.reportRecipient).put("appLock", s.appLock).put("currency", s.currency)
        .put("selectedVehicleId", s.selectedVehicleId)

    private fun settings(o: JSONObject) = BackupSettings(
        reportFrequency = runCatching { ReportFrequency.valueOf(o.getString("reportFrequency")) }.getOrDefault(ReportFrequency.OFF),
        reportRecipient = o.optString("reportRecipient"), appLock = o.optBoolean("appLock", true),
        currency = o.optString("currency", "Rs").take(4), selectedVehicleId = o.optLong("selectedVehicleId", -1),
    )

    // --- JSON mapping (explicit, so a field rename can never silently drop data) ---

    private fun vehicleJson(v: Vehicle) = JSONObject().put("id", v.id).put("name", v.name).put("make", v.make)
        .put("model", v.model).put("year", v.year ?: JSONObject.NULL).put("plate", v.plate).put("fuelType", v.fuelType.name)
        .put("tankLitres", v.tankLitres).put("initialOdometer", v.initialOdometer).put("createdOn", v.createdOn.toString())

    private fun vehicle(o: JSONObject) = Vehicle(
        id = o.getLong("id"), name = o.getString("name"), make = o.getString("make"), model = o.getString("model"),
        year = if (o.isNull("year")) null else o.getInt("year"), plate = o.getString("plate"),
        fuelType = FuelType.valueOf(o.getString("fuelType")), tankLitres = o.getDouble("tankLitres"),
        initialOdometer = o.getDouble("initialOdometer"), createdOn = LocalDate.parse(o.getString("createdOn")),
    )

    private fun fuelJson(e: FuelEntry) = JSONObject().put("id", e.id).put("vehicleId", e.vehicleId)
        .put("date", e.date.toString()).put("odometer", e.odometer).put("litres", e.litres)
        .put("pricePerLitre", e.pricePerLitre).put("totalCost", e.totalCost).put("isFull", e.isFull)
        .put("station", e.station).put("note", e.note)

    private fun fuel(o: JSONObject) = FuelEntry(
        id = o.getLong("id"), vehicleId = o.getLong("vehicleId"), date = LocalDate.parse(o.getString("date")),
        odometer = o.getDouble("odometer"), litres = o.getDouble("litres"), pricePerLitre = o.getDouble("pricePerLitre"),
        totalCost = o.getDouble("totalCost"), isFull = o.getBoolean("isFull"), station = o.optString("station"), note = o.optString("note"),
    )

    private fun itemJson(i: MaintenanceItem) = JSONObject().put("id", i.id).put("vehicleId", i.vehicleId).put("name", i.name)
        .put("intervalKm", i.intervalKm ?: JSONObject.NULL).put("intervalMonths", i.intervalMonths ?: JSONObject.NULL)
        .put("lastDoneDate", i.lastDoneDate.toString()).put("lastDoneOdometer", i.lastDoneOdometer)

    private fun item(o: JSONObject) = MaintenanceItem(
        id = o.getLong("id"), vehicleId = o.getLong("vehicleId"), name = o.getString("name"),
        intervalKm = if (o.isNull("intervalKm")) null else o.getInt("intervalKm"),
        intervalMonths = if (o.isNull("intervalMonths")) null else o.getInt("intervalMonths"),
        lastDoneDate = LocalDate.parse(o.getString("lastDoneDate")), lastDoneOdometer = o.getDouble("lastDoneOdometer"),
    )

    private fun recordJson(r: ServiceRecord) = JSONObject().put("id", r.id).put("vehicleId", r.vehicleId)
        .put("itemName", r.itemName).put("date", r.date.toString()).put("odometer", r.odometer).put("cost", r.cost).put("note", r.note)

    private fun record(o: JSONObject) = ServiceRecord(
        id = o.getLong("id"), vehicleId = o.getLong("vehicleId"), itemName = o.getString("itemName"),
        date = LocalDate.parse(o.getString("date")), odometer = o.getDouble("odometer"), cost = o.getDouble("cost"),
        note = o.optString("note"),
    )

    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

    companion object { const val SCHEMA = 2 }
}
