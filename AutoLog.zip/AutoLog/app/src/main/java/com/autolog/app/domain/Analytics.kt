package com.autolog.app.domain

import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/*
 * Pure Kotlin, no Android dependencies, so every formula is unit-testable.
 *
 * Methods used:
 *  - Fuel economy: full-to-full. Litres of every fill after a full tank, up to and
 *    including the next full tank, divided by the km between the two full tanks.
 *    Partial fills are absorbed into the segment, so they never distort the figure.
 *  - Driving rate: exponentially weighted moving average (EWMA) of km/day between
 *    odometer readings. Recent behaviour weighs more, so forecasts adapt quickly.
 *  - Maintenance: dual trigger. Due at whichever comes first, the km limit
 *    (projected to a date using the driving rate) or the calendar limit.
 */

data class FuelFill(
    val date: LocalDate,
    val odometer: Double,
    val litres: Double,
    val totalCost: Double,
    val isFull: Boolean,
)

data class OdoReading(val date: LocalDate, val odometer: Double)

data class Segment(val endDate: LocalDate, val km: Double, val litres: Double) {
    val lPer100: Double get() = litres / km * 100.0
    val kmPerL: Double get() = km / litres
}

data class MaintenanceRule(
    val id: Long,
    val name: String,
    val intervalKm: Int?,
    val intervalMonths: Int?,
    val lastDoneDate: LocalDate,
    val lastDoneOdometer: Double,
)

enum class DueStatus { OVERDUE, DUE_SOON, OK }

data class MaintenanceDue(
    val rule: MaintenanceRule,
    val dueDate: LocalDate?,
    val dueOdometer: Double?,
    val kmRemaining: Double?,
    val daysRemaining: Long?,
    val status: DueStatus,
)

data class FuelForecast(
    val estimatedOdometer: Double,
    val fuelLeftL: Double,
    val fuelLeftPct: Double,
    val rangeKm: Double,
    val daysToRefill: Long?,
    val refillDate: LocalDate?,
)

data class ConsumptionAlert(val lastLPer100: Double, val baselineLPer100: Double, val deviationPct: Double)

object Analytics {

    /** Full-to-full consumption segments, oldest first. */
    fun segments(fills: List<FuelFill>): List<Segment> {
        val sorted = fills.sortedWith(compareBy({ it.odometer }, { it.date }))
        val out = mutableListOf<Segment>()
        var lastFullOdo: Double? = null
        var litres = 0.0
        for (f in sorted) {
            if (lastFullOdo == null) {
                if (f.isFull) lastFullOdo = f.odometer
                continue
            }
            litres += f.litres
            if (f.isFull) {
                val km = f.odometer - lastFullOdo
                if (km > 0 && litres > 0) out += Segment(f.date, km, litres)
                lastFullOdo = f.odometer
                litres = 0.0
            }
        }
        return out
    }

    /** Distance-weighted average litres per km over the last [lastN] segments. */
    fun litresPerKm(segments: List<Segment>, lastN: Int = 5): Double? {
        val recent = segments.takeLast(lastN)
        val km = recent.sumOf { it.km }
        return if (km > 0) recent.sumOf { it.litres } / km else null
    }

    /** EWMA of km/day between dated odometer readings. Null until two distinct dates exist. */
    fun dailyKm(readings: List<OdoReading>, alpha: Double = 0.3): Double? {
        val byDay = readings.groupBy { it.date }
            .map { (d, r) -> OdoReading(d, r.maxOf { it.odometer }) }
            .sortedBy { it.date }
        if (byDay.size < 2) return null
        var ewma: Double? = null
        for (i in 1 until byDay.size) {
            val days = ChronoUnit.DAYS.between(byDay[i - 1].date, byDay[i].date).toDouble()
            val dKm = byDay[i].odometer - byDay[i - 1].odometer
            if (days <= 0 || dKm < 0) continue
            val rate = dKm / days
            ewma = if (ewma == null) rate else alpha * rate + (1 - alpha) * ewma
        }
        return ewma
    }

    /** Last known odometer projected forward to [today] at the current driving rate. */
    fun estimatedOdometer(readings: List<OdoReading>, dailyKm: Double?, today: LocalDate): Double? {
        val last = readings.maxWithOrNull(compareBy({ it.date }, { it.odometer })) ?: return null
        val days = max(0L, ChronoUnit.DAYS.between(last.date, today))
        return last.odometer + (dailyKm ?: 0.0) * days
    }

    fun forecast(
        fills: List<FuelFill>,
        tankLitres: Double,
        litresPerKm: Double?,
        dailyKm: Double?,
        estimatedOdometer: Double,
        today: LocalDate,
        reservePct: Double = 0.10,
    ): FuelForecast? {
        if (litresPerKm == null || litresPerKm <= 0 || tankLitres <= 0) return null
        val lastFull = fills.filter { it.isFull }.maxByOrNull { it.odometer } ?: return null
        val partials = fills.filter { !it.isFull && it.odometer > lastFull.odometer }.sumOf { it.litres }
        val kmSince = max(0.0, estimatedOdometer - lastFull.odometer)
        val fuelLeft = (tankLitres + partials - kmSince * litresPerKm).coerceIn(0.0, tankLitres)
        val usable = max(0.0, fuelLeft - tankLitres * reservePct)
        val days = dailyKm?.takeIf { it > 0 }?.let { floor(usable / litresPerKm / it).toLong() }
        return FuelForecast(
            estimatedOdometer = estimatedOdometer,
            fuelLeftL = fuelLeft,
            fuelLeftPct = fuelLeft / tankLitres * 100.0,
            rangeKm = fuelLeft / litresPerKm,
            daysToRefill = days,
            refillDate = days?.let { today.plusDays(it) },
        )
    }

    fun maintenanceDue(
        rule: MaintenanceRule,
        estimatedOdometer: Double,
        dailyKm: Double?,
        today: LocalDate,
        soonDays: Long = 30,
        soonKm: Double = 1000.0,
    ): MaintenanceDue {
        val dueOdo = rule.intervalKm?.let { rule.lastDoneOdometer + it }
        val kmRemaining = dueOdo?.let { it - estimatedOdometer }
        val dateByKm = if (kmRemaining != null && dailyKm != null && dailyKm > 0)
            today.plusDays(ceil(kmRemaining / dailyKm).toLong()) else null
        val dateByTime = rule.intervalMonths?.let { rule.lastDoneDate.plusMonths(it.toLong()) }
        val dueDate = listOfNotNull(dateByKm, dateByTime).minOrNull()
        val daysRemaining = dueDate?.let { ChronoUnit.DAYS.between(today, it) }
        val status = when {
            (kmRemaining != null && kmRemaining <= 0) || (daysRemaining != null && daysRemaining < 0) -> DueStatus.OVERDUE
            (kmRemaining != null && kmRemaining <= soonKm) || (daysRemaining != null && daysRemaining <= soonDays) -> DueStatus.DUE_SOON
            else -> DueStatus.OK
        }
        return MaintenanceDue(rule, dueDate, dueOdo, kmRemaining, daysRemaining, status)
    }

    /** Flags the latest segment when it exceeds the historical baseline by [threshold]. Needs 4+ segments. */
    fun consumptionAlert(segments: List<Segment>, threshold: Double = 0.15): ConsumptionAlert? {
        if (segments.size < 4) return null
        val last = segments.last()
        val base = segments.dropLast(1)
        val baseline = base.sumOf { it.litres } / base.sumOf { it.km } * 100.0
        val dev = (last.lPer100 - baseline) / baseline
        return if (dev > threshold) ConsumptionAlert(last.lPer100, baseline, dev * 100.0) else null
    }

    fun costPerKm(totalCost: Double, readings: List<OdoReading>): Double? {
        if (readings.size < 2) return null
        val span = readings.maxOf { it.odometer } - readings.minOf { it.odometer }
        return if (span > 0) totalCost / span else null
    }

    fun monthlyTotals(items: List<Pair<LocalDate, Double>>): Map<YearMonth, Double> =
        items.groupBy({ YearMonth.from(it.first) }, { it.second })
            .mapValues { it.value.sum() }
            .toSortedMap()
}
