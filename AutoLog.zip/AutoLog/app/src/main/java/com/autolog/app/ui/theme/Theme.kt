package com.autolog.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Instrument-cluster palette: slate dash, amber gauge needle, plain status lights.
object Palette {
    val Slate = Color(0xFF1F3A4D)
    val SlateLight = Color(0xFF9EC3D9)
    val Amber = Color(0xFFE0A030)
    val Ok = Color(0xFF2F7D57)
    val Soon = Color(0xFFC98A12)
    val Overdue = Color(0xFFB83A32)
}

private val Light = lightColorScheme(
    primary = Palette.Slate, onPrimary = Color.White,
    secondary = Palette.Amber, onSecondary = Color(0xFF2A1C00),
    background = Color(0xFFF3F5F6), surface = Color.White,
    surfaceVariant = Color(0xFFE3E9ED), onSurfaceVariant = Color(0xFF41505A),
    error = Palette.Overdue,
)

private val Dark = darkColorScheme(
    primary = Palette.SlateLight, onPrimary = Color(0xFF0B2230),
    secondary = Palette.Amber, onSecondary = Color(0xFF2A1C00),
    background = Color(0xFF0F1A21), surface = Color(0xFF16232C),
    surfaceVariant = Color(0xFF22323D), onSurfaceVariant = Color(0xFFB7C6CF),
    error = Color(0xFFE5776E),
)

/** Tabular figures keep columns of numbers aligned, like a gauge readout. */
val Readout = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum")
val ReadoutSmall = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFeatureSettings = "tnum")

@Composable
fun AutoLogTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
