package com.autolog.app.domain

import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.*
import java.security.interfaces.ECPrivateKey
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECPrivateKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class BackupException(message: String) : Exception(message)

/** Recovery key pair. [code] is shown to the user once and never stored; only [publicKey] is kept on the phone. */
class RecoveryKey(val publicKey: ByteArray, val code: String)

/**
 * Envelope encryption. Each backup has a random data key (DEK) that encrypts the content.
 * The DEK is wrapped twice, so the file opens with EITHER secret:
 *
 *  - Password slot: AES-256-GCM key from PBKDF2-HMAC-SHA256 (600,000 iterations, OWASP 2023).
 *  - Recovery slot: ECIES on P-256. An ephemeral key pair + the stored recovery PUBLIC key give
 *    a shared secret (ECDH -> HKDF-SHA256). Only the recovery code (the private key) can reverse it,
 *    so the phone can lock backups for recovery but never open them.
 *
 * File layout v2:
 *   "ALBK" | ver(1) | iterations(4) | pwSalt(16) | pwIv(12) | pwWrappedDek(48)
 *   | ephPubLen(2) | ephPub(n) | recIv(12) | recWrappedDek(48) | dataIv(12) | ciphertext+tag
 * The whole header is GCM associated data for the content, so any modification is detected.
 */
object BackupCrypto {
    private val MAGIC = "ALBK".toByteArray(Charsets.US_ASCII)
    private const val VERSION: Byte = 2
    const val ITERATIONS = 600_000
    private const val MAX_ITERATIONS = 5_000_000
    const val MIN_PASSWORD = 10
    private const val SALT = 16
    private const val IV = 12
    private const val WRAPPED = 48 // 32-byte DEK + 16-byte tag
    private val HKDF_INFO = "AutoLog recovery v2".toByteArray()
    private val rnd = SecureRandom()

    // ---------- Recovery key ----------

    fun newRecoveryKey(): RecoveryKey {
        val kp = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1"), rnd) }.generateKeyPair()
        val scalar = toFixed32((kp.private as ECPrivateKey).s)
        return RecoveryKey(kp.public.encoded, RecoveryCode.encode(scalar).also { scalar.fill(0) })
    }

    /** True if [code] is the private half of [publicKey]. Used before allowing a password reset. */
    fun recoveryMatches(code: String, publicKey: ByteArray): Boolean = try {
        val pub = decodePublic(publicKey)
        val priv = privateFromCode(code, pub)
        val probe = KeyPairGenerator.getInstance("EC").apply { initialize(pub.params, rnd) }.generateKeyPair()
        MessageDigest.isEqual(ecdh(probe.private, pub), ecdh(priv, probe.public as ECPublicKey))
    } catch (e: BackupException) { false }

    // ---------- Password verifier (stops a mistyped password producing an unusable backup) ----------

    fun makeVerifier(password: CharArray, iterations: Int = ITERATIONS): ByteArray {
        checkPassword(password)
        val salt = ByteArray(SALT).also(rnd::nextBytes)
        return ByteBuffer.allocate(4 + SALT + 32).putInt(iterations).put(salt).put(pbkdf2(password, salt, iterations)).array()
    }

    fun checkVerifier(password: CharArray, verifier: ByteArray): Boolean {
        val b = ByteBuffer.wrap(verifier)
        val iterations = b.int
        val salt = ByteArray(SALT).also { b.get(it) }
        val hash = ByteArray(32).also { b.get(it) }
        return MessageDigest.isEqual(hash, pbkdf2(password, salt, iterations))
    }

    // ---------- Encrypt / decrypt ----------

    fun encrypt(plain: ByteArray, password: CharArray, recoveryPublicKey: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        checkPassword(password)
        val dek = ByteArray(32).also(rnd::nextBytes)
        try {
            val prefix = ByteBuffer.allocate(9).put(MAGIC).put(VERSION).putInt(iterations).array()

            val pwSalt = ByteArray(SALT).also(rnd::nextBytes)
            val pwIv = ByteArray(IV).also(rnd::nextBytes)
            val pwWrapped = gcm(Cipher.ENCRYPT_MODE, pbkdf2(password, pwSalt, iterations), pwIv, prefix, dek)

            val recPub = decodePublic(recoveryPublicKey)
            val eph = KeyPairGenerator.getInstance("EC").apply { initialize(recPub.params, rnd) }.generateKeyPair()
            val ephPub = eph.public.encoded
            val recIv = ByteArray(IV).also(rnd::nextBytes)
            val recWrapped = gcm(Cipher.ENCRYPT_MODE, hkdf(ecdh(eph.private, recPub), ephPub), recIv, prefix, dek)

            val dataIv = ByteArray(IV).also(rnd::nextBytes)
            val header = ByteBuffer.allocate(9 + SALT + IV + WRAPPED + 2 + ephPub.size + IV + WRAPPED + IV)
                .put(prefix).put(pwSalt).put(pwIv).put(pwWrapped)
                .putShort(ephPub.size.toShort()).put(ephPub).put(recIv).put(recWrapped).put(dataIv).array()
            return header + gcm(Cipher.ENCRYPT_MODE, dek, dataIv, header, plain)
        } finally { dek.fill(0) }
    }

    fun decryptWithPassword(blob: ByteArray, password: CharArray): ByteArray {
        val h = parse(blob)
        val dek = unwrap { gcm(Cipher.DECRYPT_MODE, pbkdf2(password, h.pwSalt, h.iterations), h.pwIv, h.prefix, h.pwWrapped) }
        return openContent(blob, h, dek)
    }

    fun decryptWithRecovery(blob: ByteArray, code: String): ByteArray {
        val h = parse(blob)
        val ephPub = decodePublic(h.ephPub)
        val priv = privateFromCode(code, ephPub)
        val dek = unwrap { gcm(Cipher.DECRYPT_MODE, hkdf(ecdh(priv, ephPub), h.ephPub), h.recIv, h.prefix, h.recWrapped) }
        return openContent(blob, h, dek)
    }

    // ---------- internals ----------

    private class Header(
        val prefix: ByteArray, val iterations: Int, val pwSalt: ByteArray, val pwIv: ByteArray, val pwWrapped: ByteArray,
        val ephPub: ByteArray, val recIv: ByteArray, val recWrapped: ByteArray, val dataIv: ByteArray, val length: Int,
    )

    private fun parse(blob: ByteArray): Header {
        try {
            val b = ByteBuffer.wrap(blob)
            val magic = ByteArray(4).also { b.get(it) }
            if (!magic.contentEquals(MAGIC)) throw BackupException("Not an AutoLog backup file")
            val ver = b.get()
            if (ver != VERSION) throw BackupException("Backup version $ver is not supported by this app version")
            val iterations = b.int
            if (iterations !in 100_000..MAX_ITERATIONS) throw BackupException("Backup file header is invalid")
            val pwSalt = ByteArray(SALT).also { b.get(it) }
            val pwIv = ByteArray(IV).also { b.get(it) }
            val pwWrapped = ByteArray(WRAPPED).also { b.get(it) }
            val n = b.short.toInt()
            if (n !in 50..200) throw BackupException("Backup file header is invalid")
            val ephPub = ByteArray(n).also { b.get(it) }
            val recIv = ByteArray(IV).also { b.get(it) }
            val recWrapped = ByteArray(WRAPPED).also { b.get(it) }
            val dataIv = ByteArray(IV).also { b.get(it) }
            if (b.remaining() < 16) throw BackupException("Not an AutoLog backup file")
            return Header(blob.copyOfRange(0, 9), iterations, pwSalt, pwIv, pwWrapped, ephPub, recIv, recWrapped, dataIv, b.position())
        } catch (e: java.nio.BufferUnderflowException) {
            throw BackupException("Not an AutoLog backup file")
        }
    }

    private fun openContent(blob: ByteArray, h: Header, dek: ByteArray): ByteArray = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(dek, "AES"), GCMParameterSpec(128, h.dataIv))
        c.updateAAD(blob, 0, h.length)
        c.doFinal(blob, h.length, blob.size - h.length)
    } catch (e: AEADBadTagException) {
        throw BackupException("The file has been modified or damaged")
    } finally { dek.fill(0) }

    private inline fun unwrap(block: () -> ByteArray): ByteArray = try { block() } catch (e: AEADBadTagException) {
        // GCM can't tell a wrong secret from a modified file; saying which would help an attacker.
        throw BackupException("Wrong password or recovery code, or the file has been modified")
    }

    private fun gcm(mode: Int, key: ByteArray, iv: ByteArray, aad: ByteArray, data: ByteArray): ByteArray =
        Cipher.getInstance("AES/GCM/NoPadding").run {
            init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv)); updateAAD(aad); doFinal(data)
        }

    private fun pbkdf2(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, 256)
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    private fun ecdh(priv: PrivateKey, pub: PublicKey): ByteArray =
        KeyAgreement.getInstance("ECDH").run { init(priv); doPhase(pub, true); generateSecret() }

    /** HKDF-SHA256 (RFC 5869), one 32-byte block. */
    private fun hkdf(ikm: ByteArray, salt: ByteArray): ByteArray {
        val prk = Mac.getInstance("HmacSHA256").run { init(SecretKeySpec(salt, "HmacSHA256")); doFinal(ikm) }
        return Mac.getInstance("HmacSHA256").run { init(SecretKeySpec(prk, "HmacSHA256")); update(HKDF_INFO); doFinal(byteArrayOf(1)) }
    }

    private fun decodePublic(bytes: ByteArray): ECPublicKey = try {
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(bytes)) as ECPublicKey
    } catch (e: Exception) { throw BackupException("Backup file header is invalid") }

    private fun privateFromCode(code: String, curveOf: ECPublicKey): PrivateKey {
        val scalar = RecoveryCode.decode(code)
        try {
            return KeyFactory.getInstance("EC").generatePrivate(ECPrivateKeySpec(BigInteger(1, scalar), curveOf.params))
        } finally { scalar.fill(0) }
    }

    private fun checkPassword(p: CharArray) {
        if (p.size < MIN_PASSWORD) throw BackupException("Password must be at least $MIN_PASSWORD characters")
    }

    private fun toFixed32(v: BigInteger): ByteArray {
        val raw = v.toByteArray()
        return when {
            raw.size == 32 -> raw
            raw.size > 32 -> raw.copyOfRange(raw.size - 32, raw.size)
            else -> ByteArray(32 - raw.size) + raw
        }
    }
}

/**
 * 32-byte key + 3-byte SHA-256 checksum = 280 bits = 56 Crockford base32 characters,
 * shown as 14 groups of 4. The checksum catches typos before any decryption is attempted.
 */
object RecoveryCode {
    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

    fun encode(key: ByteArray): String {
        val data = key + checksum(key)
        val sb = StringBuilder()
        var buffer = 0; var bits = 0
        for (b in data) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF); bits += 8
            while (bits >= 5) { bits -= 5; sb.append(ALPHABET[(buffer shr bits) and 31]) }
        }
        return sb.chunked(4).joinToString("-")
    }

    fun decode(code: String): ByteArray {
        val clean = code.uppercase().filter { it.isLetterOrDigit() }
            .map { when (it) { 'O' -> '0'; 'I', 'L' -> '1'; else -> it } }
        if (clean.size != 56) throw BackupException("Recovery code must be 56 characters")
        val out = ByteArray(35)
        var buffer = 0; var bits = 0; var i = 0
        for (ch in clean) {
            val v = ALPHABET.indexOf(ch)
            if (v < 0) throw BackupException("Recovery code contains an invalid character: $ch")
            buffer = (buffer shl 5) or v; bits += 5
            if (bits >= 8) { bits -= 8; out[i++] = (buffer shr bits).toByte() }
        }
        val key = out.copyOfRange(0, 32)
        if (!MessageDigest.isEqual(checksum(key), out.copyOfRange(32, 35))) {
            key.fill(0); throw BackupException("Recovery code is incorrect. Check for typos.")
        }
        return key
    }

    private fun checksum(key: ByteArray) = MessageDigest.getInstance("SHA-256").digest(key).copyOfRange(0, 3)
}
