package com.autolog.app.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.autolog.app.data.MaintenanceItem
import com.autolog.app.report.ShareReport
import com.autolog.app.ui.components.VehiclePicker
import com.autolog.app.ui.screens.*
import com.autolog.app.ui.theme.AutoLogTheme
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

private enum class AppTab(val label: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Outlined.Speed),
    FUEL("Fuel", Icons.Outlined.LocalGasStation),
    SERVICE("Service", Icons.Outlined.Build),
    GARAGE("Garage", Icons.Outlined.DirectionsCar),
    REPORTS("Reports", Icons.Outlined.Assessment),
}

private sealed interface Form {
    data object AddVehicle : Form
    data object AddFuel : Form
    data class MarkDone(val item: MaintenanceItem) : Form
    data class EditItem(val item: MaintenanceItem) : Form
}

class MainActivity : FragmentActivity() {
    private val vm: AppViewModel by viewModels()
    private var unlocked by mutableStateOf(false)
    private var pendingShare: File? = null
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutoLogTheme { if (unlocked || !vm.store.appLock) AppRoot(vm, ::share) else Locked(::authenticate) } }
        authenticate()
        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        val path = intent?.getStringExtra(EXTRA_SHARE_REPORT) ?: return
        intent.removeExtra(EXTRA_SHARE_REPORT)
        val file = File(path)
        // Only accept files from our own cache directory.
        if (!file.exists() || !file.canonicalPath.startsWith(File(cacheDir, "reports").canonicalPath)) return
        // Never open the report before the lock screen is passed.
        if (unlocked) share(file) else pendingShare = file
    }

    private fun share(file: File) = startActivity(ShareReport.intent(this, file, vm.store.reportRecipient))

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun authenticate() {
        if (!vm.store.appLock) { onUnlocked(); return }
        val authenticators = BIOMETRIC_WEAK or DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            onUnlocked() // no screen lock configured on the device; nothing to verify against
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onUnlocked()
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock AutoLog")
                .setAllowedAuthenticators(authenticators)
                .build()
        )
    }

    private fun onUnlocked() {
        unlocked = true
        pendingShare?.let { pendingShare = null; share(it) }
    }

    companion object { const val EXTRA_SHARE_REPORT = "share_report_path" }
}

@Composable
private fun Locked(onUnlock: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Button(onUnlock) { Text("Unlock") } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(vm: AppViewModel, share: (File) -> Unit) {
    val vehicles by vm.vehicles.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val insights by vm.insights.collectAsStateWithLifecycle()
    val fuel by vm.fuelEntries.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val freq by vm.frequency.collectAsStateWithLifecycle()
    val recipient by vm.recipient.collectAsStateWithLifecycle()
    val currency by vm.currency.collectAsStateWithLifecycle()
    val appLock by vm.appLock.collectAsStateWithLifecycle()
    val backupFlow = rememberBackupFlow(vm)

    var tab by rememberSaveable { mutableStateOf(AppTab.DASHBOARD) }
    var form by remember { mutableStateOf<Form?>(null) }
    var lastOdo by remember { mutableDoubleStateOf(0.0) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val activity = androidx.compose.ui.platform.LocalContext.current as MainActivity

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.message.value = null } }
    BackHandler(form != null) { form = null }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { VehiclePicker(vehicles, selected, vm::select) },
                navigationIcon = { if (form != null) IconButton({ form = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            if (form == null) NavigationBar {
                AppTab.entries.forEach { t ->
                    NavigationBarItem(tab == t, { tab = t }, { Icon(t.icon, null) }, label = { Text(t.label) })
                }
            }
        },
        floatingActionButton = {
            if (form == null) when (tab) {
                AppTab.FUEL -> selected?.let {
                    FloatingActionButton({ scope.launch { lastOdo = vm.latestOdometer(); form = Form.AddFuel } }) { Icon(Icons.Default.Add, "Log fill-up") }
                }
                AppTab.SERVICE -> selected?.let { v ->
                    FloatingActionButton({
                        form = Form.EditItem(MaintenanceItem(vehicleId = v.id, name = "", intervalKm = null, intervalMonths = null,
                            lastDoneDate = LocalDate.now(), lastDoneOdometer = insights?.estimatedOdometer ?: v.initialOdometer))
                    }) { Icon(Icons.Default.Add, "Add maintenance item") }
                }
                AppTab.GARAGE -> FloatingActionButton({ form = Form.AddVehicle }) { Icon(Icons.Default.Add, "Add vehicle") }
                else -> {}
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (val f = form) {
                Form.AddVehicle -> AddVehicleScreen { vm.addVehicle(it) { form = null; tab = AppTab.DASHBOARD } }
                Form.AddFuel -> selected?.let { v -> AddFuelScreen(v, lastOdo, currency) { vm.addFuel(it) { form = null } } }
                is Form.MarkDone -> MarkDoneScreen(f.item, insights?.estimatedOdometer ?: 0.0, currency) { d, o, c, n ->
                    vm.markDone(f.item, d, o, c, n) { form = null }
                }
                is Form.EditItem -> EditItemScreen(f.item, { vm.saveItem(it) { form = null } }, { vm.deleteItem(it); form = null })
                null -> when (tab) {
                    AppTab.DASHBOARD -> DashboardScreen(insights, currency, { form = Form.AddVehicle }) {
                        scope.launch { lastOdo = vm.latestOdometer(); form = Form.AddFuel }
                    }
                    AppTab.FUEL -> FuelLogScreen(fuel, currency, vm::deleteFuel)
                    AppTab.SERVICE -> MaintenanceScreen(insights, items, records, currency,
                        { form = Form.MarkDone(it) }, { form = Form.EditItem(it) })
                    AppTab.GARAGE -> GarageScreen(vehicles, selected?.id, { vm.select(it); tab = AppTab.DASHBOARD }, vm::deleteVehicle)
                    AppTab.REPORTS -> ReportsScreen(
                        freq, recipient, appLock, currency,
                        onSaveSchedule = { fr, e -> activity.requestNotifications(); vm.saveSchedule(fr, e) },
                        onExport = { vm.exportNow(share) },
                        onAppLock = vm::setAppLock,
                        onCurrency = vm::setCurrency,
                        backupSection = { BackupSection(vm, backupFlow) },
                    )
                }
            }
        }
    }
}
