package com.autolog.app.data

import com.autolog.app.domain.*
import java.time.LocalDate
import java.time.YearMonth

data class VehicleInsights(
    val vehicle: Vehicle,
    val segments: List<Segment>,
    val avgLPer100: Double?,
    val dailyKm: Double?,
    val estimatedOdometer: Double,
    val forecast: FuelForecast?,
    val alert: ConsumptionAlert?,
    val maintenance: List<MaintenanceDue>,
    val costPerKm: Double?,
    val fuelByMonth: Map<YearMonth, Double>,
    val serviceByMonth: Map<YearMonth, Double>,
    val totalFuelCost: Double,
    val totalServiceCost: Double,
    val totalLitres: Double,
)

class ValidationException(message: String) : Exception(message)

class Repository(private val db: AppDatabase) {
    val vehicles = db.vehicles()
    val fuel = db.fuel()
    val maintenance = db.maintenance()

    suspend fun addVehicle(v: Vehicle): Long {
        requireText(v.name, "Enter a vehicle name")
        if (v.tankLitres !in 5.0..200.0) throw ValidationException("Tank capacity must be between 5 and 200 L")
        if (v.initialOdometer < 0) throw ValidationException("Odometer cannot be negative")
        val id = vehicles.insert(v)
        maintenance.insertItems(MaintenanceTemplates.forType(v.fuelType).map {
            MaintenanceItem(
                vehicleId = id, name = it.name, intervalKm = it.intervalKm, intervalMonths = it.intervalMonths,
                lastDoneDate = v.createdOn, lastDoneOdometer = v.initialOdometer,
            )
        })
        return id
    }

    suspend fun addFuel(v: Vehicle, e: FuelEntry) {
        if (e.litres <= 0 || e.litres > v.tankLitres * 1.1)
            throw ValidationException("Litres must be above 0 and within the ${v.tankLitres.toInt()} L tank")
        val last = latestOdometer(v)
        if (e.odometer < last) throw ValidationException("Odometer is below the last reading (${last.toLong()} km)")
        if (e.date.isAfter(LocalDate.now())) throw ValidationException("Date cannot be in the future")
        fuel.insert(e)
    }

    suspend fun markServiceDone(v: Vehicle, item: MaintenanceItem, date: LocalDate, odometer: Double, cost: Double, note: String) {
        if (odometer < v.initialOdometer) throw ValidationException("Odometer is below the vehicle's starting reading")
        if (cost < 0) throw ValidationException("Cost cannot be negative")
        maintenance.markDone(item, ServiceRecord(vehicleId = v.id, itemName = item.name, date = date, odometer = odometer, cost = cost, note = note))
    }

    suspend fun latestOdometer(v: Vehicle): Double =
        listOfNotNull(v.initialOdometer, fuel.maxOdometer(v.id), maintenance.maxOdometer(v.id)).max()

    suspend fun insights(v: Vehicle, today: LocalDate = LocalDate.now()): VehicleInsights {
        val entries = fuel.forVehicle(v.id)
        val records = maintenance.records(v.id)
        val items = maintenance.items(v.id)

        val fills = entries.map { FuelFill(it.date, it.odometer, it.litres, it.totalCost, it.isFull) }
        val readings = buildList {
            add(OdoReading(v.createdOn, v.initialOdometer))
            entries.forEach { add(OdoReading(it.date, it.odometer)) }
            records.forEach { add(OdoReading(it.date, it.odometer)) }
        }
        val segments = Analytics.segments(fills)
        val lPerKm = Analytics.litresPerKm(segments)
        val daily = Analytics.dailyKm(readings)
        val estOdo = Analytics.estimatedOdometer(readings, daily, today) ?: v.initialOdometer
        val fuelCost = entries.sumOf { it.totalCost }
        val serviceCost = records.sumOf { it.cost }

        return VehicleInsights(
            vehicle = v,
            segments = segments,
            avgLPer100 = lPerKm?.times(100),
            dailyKm = daily,
            estimatedOdometer = estOdo,
            forecast = Analytics.forecast(fills, v.tankLitres, lPerKm, daily, estOdo, today),
            alert = Analytics.consumptionAlert(segments),
            maintenance = items.map {
                Analytics.maintenanceDue(
                    MaintenanceRule(it.id, it.name, it.intervalKm, it.intervalMonths, it.lastDoneDate, it.lastDoneOdometer),
                    estOdo, daily, today,
                )
            }.sortedWith(compareBy({ it.status.ordinal }, { it.daysRemaining ?: Long.MAX_VALUE })),
            costPerKm = Analytics.costPerKm(fuelCost + serviceCost, readings),
            fuelByMonth = Analytics.monthlyTotals(entries.map { it.date to it.totalCost }),
            serviceByMonth = Analytics.monthlyTotals(records.map { it.date to it.cost }),
            totalFuelCost = fuelCost,
            totalServiceCost = serviceCost,
            totalLitres = entries.sumOf { it.litres },
        )
    }

    private fun requireText(value: String, msg: String) { if (value.isBlank()) throw ValidationException(msg) }
}
