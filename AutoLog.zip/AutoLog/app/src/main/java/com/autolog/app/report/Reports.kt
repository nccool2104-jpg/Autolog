package com.autolog.app.report

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.work.*
import com.autolog.app.App
import com.autolog.app.R
import com.autolog.app.data.ReportFrequency
import com.autolog.app.data.VehicleInsights
import com.autolog.app.ui.MainActivity
import org.dhatim.fastexcel.Workbook
import org.dhatim.fastexcel.Worksheet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object ExcelReport {

    /** Builds one workbook covering every vehicle. File lives in app cache, shared only via FileProvider. */
    suspend fun build(context: Context): File = withContext(Dispatchers.IO) {
        val repo = (context.applicationContext as App).repository
        val currency = (context.applicationContext as App).store.currency
        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // keep only the latest export on the device
        val file = File(dir, "AutoLog_${LocalDate.now().format(DateTimeFormatter.ISO_DATE)}.xlsx")

        val vehicles = repo.vehicles.all()
        val insights = vehicles.map { repo.insights(it) }

        file.outputStream().use { out ->
            val wb = Workbook(out, "AutoLog", "1.0")

            wb.newWorksheet("Summary").apply {
                header(this, "Vehicle", "Plate", "Odometer (est.)", "Avg L/100km", "km/day",
                    "Fuel left %", "Next refill", "Fuel cost ($currency)", "Service cost ($currency)",
                    "Cost per km", "Overdue items", "Consumption alert")
                insights.forEachIndexed { i, s ->
                    val r = i + 1
                    value(r, 0, s.vehicle.name); value(r, 1, s.vehicle.plate)
                    num(this, r, 2, s.estimatedOdometer, "#,##0")
                    num(this, r, 3, s.avgLPer100, "0.00")
                    num(this, r, 4, s.dailyKm, "0.0")
                    num(this, r, 5, s.forecast?.fuelLeftPct, "0")
                    date(this, r, 6, s.forecast?.refillDate)
                    num(this, r, 7, s.totalFuelCost, "#,##0.00")
                    num(this, r, 8, s.totalServiceCost, "#,##0.00")
                    num(this, r, 9, s.costPerKm, "0.00")
                    value(r, 10, s.maintenance.count { it.status.name == "OVERDUE" })
                    value(r, 11, s.alert?.let { "+%.0f%% vs baseline".format(it.deviationPct) } ?: "")
                }
                widths(this, 12)
            }

            wb.newWorksheet("Fuel log").apply {
                header(this, "Vehicle", "Date", "Odometer", "Litres", "Price/L", "Total", "Full tank", "Station", "Note")
                var r = 1
                vehicles.forEach { v ->
                    repo.fuel.forVehicle(v.id).forEach { e ->
                        value(r, 0, v.name); date(this, r, 1, e.date)
                        num(this, r, 2, e.odometer, "#,##0"); num(this, r, 3, e.litres, "0.00")
                        num(this, r, 4, e.pricePerLitre, "0.00"); num(this, r, 5, e.totalCost, "#,##0.00")
                        value(r, 6, if (e.isFull) "Yes" else "No"); value(r, 7, e.station); value(r, 8, e.note)
                        r++
                    }
                }
                widths(this, 9)
            }

            wb.newWorksheet("Consumption").apply {
                header(this, "Vehicle", "Segment end", "km", "Litres", "L/100km", "km/L")
                var r = 1
                insights.forEach { s ->
                    s.segments.forEach { g ->
                        value(r, 0, s.vehicle.name); date(this, r, 1, g.endDate)
                        num(this, r, 2, g.km, "#,##0"); num(this, r, 3, g.litres, "0.00")
                        num(this, r, 4, g.lPer100, "0.00"); num(this, r, 5, g.kmPerL, "0.00")
                        r++
                    }
                }
                widths(this, 6)
            }

            wb.newWorksheet("Maintenance due").apply {
                header(this, "Vehicle", "Item", "Status", "Due date", "Due odometer", "km remaining", "Days remaining", "Interval km", "Interval months")
                var r = 1
                insights.forEach { s ->
                    s.maintenance.forEach { m ->
                        value(r, 0, s.vehicle.name); value(r, 1, m.rule.name); value(r, 2, m.status.name.replace('_', ' '))
                        date(this, r, 3, m.dueDate); num(this, r, 4, m.dueOdometer, "#,##0")
                        num(this, r, 5, m.kmRemaining, "#,##0"); m.daysRemaining?.let { value(r, 6, it) }
                        m.rule.intervalKm?.let { value(r, 7, it) }; m.rule.intervalMonths?.let { value(r, 8, it) }
                        r++
                    }
                }
                widths(this, 9)
            }

            wb.newWorksheet("Service history").apply {
                header(this, "Vehicle", "Date", "Item", "Odometer", "Cost", "Note")
                var r = 1
                vehicles.forEach { v ->
                    repo.maintenance.records(v.id).forEach { s ->
                        value(r, 0, v.name); date(this, r, 1, s.date); value(r, 2, s.itemName)
                        num(this, r, 3, s.odometer, "#,##0"); num(this, r, 4, s.cost, "#,##0.00"); value(r, 5, s.note)
                        r++
                    }
                }
                widths(this, 6)
            }

            wb.newWorksheet("Monthly spend").apply {
                header(this, "Vehicle", "Month", "Fuel", "Service", "Total")
                var r = 1
                insights.forEach { s ->
                    (s.fuelByMonth.keys + s.serviceByMonth.keys).toSortedSet().forEach { m ->
                        val f = s.fuelByMonth[m] ?: 0.0; val sv = s.serviceByMonth[m] ?: 0.0
                        value(r, 0, s.vehicle.name); value(r, 1, m.toString())
                        num(this, r, 2, f, "#,##0.00"); num(this, r, 3, sv, "#,##0.00"); num(this, r, 4, f + sv, "#,##0.00")
                        r++
                    }
                }
                widths(this, 5)
            }
            wb.finish()
        }
        file
    }

    private fun header(ws: Worksheet, vararg titles: String) {
        titles.forEachIndexed { c, t -> ws.value(0, c, t) }
        ws.range(0, 0, 0, titles.size - 1).style().bold().fillColor("DDE6EC").set()
        ws.freezePane(0, 1)
    }

    private fun num(ws: Worksheet, r: Int, c: Int, v: Double?, fmt: String) {
        if (v == null) return
        ws.value(r, c, v); ws.style(r, c).format(fmt).set()
    }

    private fun date(ws: Worksheet, r: Int, c: Int, d: LocalDate?) {
        if (d == null) return
        ws.value(r, c, d); ws.style(r, c).format("yyyy-mm-dd").set()
    }

    private fun widths(ws: Worksheet, cols: Int) = repeat(cols) { ws.width(it, 16.0) }
}

object ShareReport {
    private const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    fun intent(context: Context, file: File, recipient: String): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = XLSX
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "AutoLog vehicle report – ${LocalDate.now()}")
            putExtra(Intent.EXTRA_TEXT, "Attached: fuel, consumption, maintenance and spend report.")
            if (recipient.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, "Send report")
    }
}

/**
 * Runs on the chosen schedule, builds the workbook and posts a notification.
 * Tapping it opens the share sheet with the file attached: you review and press send.
 */
class ReportWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val file = ExcelReport.build(applicationContext)
        notify(file)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    private fun notify(file: File) {
        val ctx = applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Scheduled reports", NotificationManager.IMPORTANCE_DEFAULT))
        val open = Intent(ctx, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_SHARE_REPORT, file.absolutePath)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle("Vehicle report ready")
            .setContentText(backupReminder(ctx) ?: "Tap to email the Excel report")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(NOTIFICATION_ID, n)
    }

    /** Nudges when the last encrypted backup is missing or older than 30 days. */
    private fun backupReminder(ctx: Context): String? {
        val last = (ctx as App).store.lastBackup
            ?: return "Report ready. No encrypted backup yet: create one in Reports."
        val days = java.time.temporal.ChronoUnit.DAYS.between(last, LocalDate.now())
        return if (days > 30) "Report ready. Last backup was $days days ago." else null
    }

    companion object {
        private const val CHANNEL = "reports"
        private const val NOTIFICATION_ID = 42
        private const val WORK = "scheduled_report"

        fun schedule(context: Context, freq: ReportFrequency) {
            val wm = WorkManager.getInstance(context)
            if (freq == ReportFrequency.OFF) { wm.cancelUniqueWork(WORK); return }
            val req = PeriodicWorkRequestBuilder<ReportWorker>(freq.days, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
