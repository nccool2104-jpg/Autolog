package com.autolog.app

import android.app.Application
import com.autolog.app.data.AppDatabase
import com.autolog.app.data.BackupManager
import com.autolog.app.data.BackupVault
import com.autolog.app.data.Repository
import com.autolog.app.data.SecureStore

class App : Application() {
    val store by lazy { SecureStore(this) }
    val database by lazy { AppDatabase.build(this) }
    val repository by lazy { Repository(database) }
    val backup by lazy { BackupManager(database) }
    val vault by lazy { BackupVault(this, store) }
}
