package com.autolog.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.autolog.app.data.MaintenanceItem
import com.autolog.app.data.ServiceRecord
import com.autolog.app.data.VehicleInsights
import com.autolog.app.ui.components.*
import java.time.LocalDate

@Composable
fun MaintenanceScreen(
    s: VehicleInsights?, items: List<MaintenanceItem>, records: List<ServiceRecord>, currency: String,
    onMarkDone: (MaintenanceItem) -> Unit, onEdit: (MaintenanceItem) -> Unit,
) {
    if (s == null) { EmptyHint("Add a vehicle first.", Modifier.padding(16.dp)); return }
    var showHistory by remember { mutableStateOf(false) }
    Column {
        TabRow(if (showHistory) 1 else 0) {
            Tab(!showHistory, { showHistory = false }, text = { Text("Schedule") })
            Tab(showHistory, { showHistory = true }, text = { Text("History") })
        }
        if (!showHistory) {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(s.maintenance, key = { it.rule.id }) { m ->
                    val item = items.firstOrNull { it.id == m.rule.id } ?: return@items
                    Card(Modifier.fillMaxWidth().clickable { onMarkDone(item) }) {
                        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            StatusDot(m.status); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.rule.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    statusLabel(m.status) + ": " + listOfNotNull(
                                        m.kmRemaining?.let { if (it >= 0) "${it.fmt()} km left" else "${(-it).fmt()} km over" },
                                        m.daysRemaining?.let { if (it >= 0) "$it days" else "${-it} days late" },
                                    ).joinToString(", "),
                                    style = MaterialTheme.typography.bodySmall,
                                )
                                Text(
                                    "Every " + listOfNotNull(m.rule.intervalKm?.let { "${it.toDouble().fmt()} km" },
                                        m.rule.intervalMonths?.let { "$it months" }).joinToString(" or "),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            IconButton({ onEdit(item) }) { Icon(Icons.Outlined.Edit, "Edit interval") }
                        }
                    }
                }
            }
        } else {
            if (records.isEmpty()) EmptyHint("No services recorded yet.", Modifier.padding(16.dp))
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(r.itemName, style = MaterialTheme.typography.titleSmall)
                            Text("${r.date}  ·  ${r.odometer.fmt()} km  ·  $currency ${r.cost.fmt(2)}", style = MaterialTheme.typography.bodySmall)
                            if (r.note.isNotBlank()) Text(r.note, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MarkDoneScreen(item: MaintenanceItem, estOdometer: Double, currency: String,
                   onSave: (LocalDate, Double, Double, String) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now()) }
    var odo by remember { mutableStateOf(estOdometer.toLong().toString()) }
    var cost by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Record: ${item.name}", style = MaterialTheme.typography.titleLarge)
        Text("Resets the countdown from this date and odometer.", style = MaterialTheme.typography.bodySmall)
        DateField("Date done", date) { date = it }
        NumberField("Odometer", odo, { odo = it }, suffix = "km")
        NumberField("Cost", cost, { cost = it }, suffix = currency)
        OutlinedTextField(note, { note = it }, label = { Text("Note, e.g. garage or part brand") }, modifier = Modifier.fillMaxWidth())
        Button({ onSave(date, odo.toDoubleOrNull() ?: -1.0, cost.toDoubleOrNull() ?: 0.0, note.trim()) },
            enabled = odo.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Record service") }
    }
}

@Composable
fun EditItemScreen(item: MaintenanceItem, onSave: (MaintenanceItem) -> Unit, onDelete: (MaintenanceItem) -> Unit) {
    var name by remember { mutableStateOf(item.name) }
    var km by remember { mutableStateOf(item.intervalKm?.toString() ?: "") }
    var months by remember { mutableStateOf(item.intervalMonths?.toString() ?: "") }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (item.id == 0L) "New maintenance item" else "Edit ${item.name}", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Item") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        NumberField("Every", km, { km = it.filter(Char::isDigit) }, suffix = "km")
        NumberField("Or every", months, { months = it.filter(Char::isDigit) }, suffix = "months")
        Text("Whichever comes first. Leave one blank to use a single trigger. Use the manufacturer's service manual as the source.",
            style = MaterialTheme.typography.bodySmall)
        Button({ onSave(item.copy(name = name.trim(), intervalKm = km.toIntOrNull(), intervalMonths = months.toIntOrNull())) },
            modifier = Modifier.fillMaxWidth()) { Text("Save item") }
        if (item.id != 0L) OutlinedButton({ confirm = true }, Modifier.fillMaxWidth()) { Text("Remove item") }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Remove ${item.name}?") },
        text = { Text("Its schedule is removed. Past service records are kept.") },
        confirmButton = { TextButton({ onDelete(item); confirm = false }) { Text("Remove") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Keep") } },
    )
}
