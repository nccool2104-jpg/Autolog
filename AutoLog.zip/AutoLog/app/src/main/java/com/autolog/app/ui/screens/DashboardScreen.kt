package com.autolog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.autolog.app.data.VehicleInsights
import com.autolog.app.ui.components.*
import com.autolog.app.ui.theme.Palette
import com.autolog.app.ui.theme.ReadoutSmall
import java.time.format.DateTimeFormatter

private val dayFmt = DateTimeFormatter.ofPattern("EEE d MMM")

@Composable
fun DashboardScreen(s: VehicleInsights?, currency: String, onAddVehicle: () -> Unit, onAddFuel: () -> Unit) {
    if (s == null) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Add your first vehicle to start tracking fuel and maintenance.", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
            Button(onAddVehicle) { Text("Add vehicle") }
        }
        return
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

        // The gauge is the hero: fuel now, and when you'll need more.
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                FuelGauge(s.forecast?.fuelLeftPct, Modifier.fillMaxWidth(0.8f).align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(12.dp))
                val f = s.forecast
                Text(
                    when {
                        f == null -> "Log two full tanks to estimate fuel level and refill date."
                        f.refillDate == null -> "About ${f.rangeKm.fmt()} km of range left."
                        f.daysToRefill!! <= 0 -> "Refill now: about ${f.rangeKm.fmt()} km left, reserve reached."
                        else -> "Refill by ${f.refillDate.format(dayFmt)}, about ${f.rangeKm.fmt()} km of range left."
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                Text("Estimated odometer ${s.estimatedOdometer.fmt()} km", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onAddFuel) { Text("Log fill-up") }
            }
        }

        s.alert?.let {
            Card(colors = CardDefaults.cardColors(containerColor = Palette.Overdue.copy(alpha = 0.12f))) {
                Text(
                    "Last tank used ${it.lastLPer100.fmt(1)} L/100 km, ${it.deviationPct.fmt()}% above your ${it.baselineLPer100.fmt(1)} baseline. " +
                        "Check tyre pressure, load and driving conditions; persistent spikes can indicate a leak or fuel loss.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric("Consumption", s.avgLPer100?.let { "${it.fmt(1)} L/100" } ?: "—", Modifier.weight(1f))
            Metric("Driving", s.dailyKm?.let { "${it.fmt()} km/day" } ?: "—", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric("Cost per km", s.costPerKm?.let { "$currency ${it.fmt(2)}" } ?: "—", Modifier.weight(1f))
            Metric("Total spend", "$currency ${(s.totalFuelCost + s.totalServiceCost).fmt()}", Modifier.weight(1f))
        }

        Section("Consumption trend, L/100 km") { LineChart(s.segments.takeLast(12).map { it.lPer100 }) }

        Section("Monthly spend, last 6 months") {
            val months = (s.fuelByMonth.keys + s.serviceByMonth.keys).toSortedSet().toList().takeLast(6)
            BarChart(months.map { m ->
                m.month.name.take(3).lowercase().replaceFirstChar(Char::uppercase) to
                    ((s.fuelByMonth[m] ?: 0.0) + (s.serviceByMonth[m] ?: 0.0))
            })
        }

        Section("Coming up") {
            val upcoming = s.maintenance.take(5)
            if (upcoming.isEmpty()) EmptyHint("No maintenance items")
            upcoming.forEach { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(m.status); Spacer(Modifier.width(10.dp))
                    Text(m.rule.name, Modifier.weight(1f))
                    Text(
                        listOfNotNull(
                            m.kmRemaining?.let { "${it.fmt()} km" },
                            m.dueDate?.format(dayFmt),
                        ).joinToString(" or "),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = ReadoutSmall)
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}
