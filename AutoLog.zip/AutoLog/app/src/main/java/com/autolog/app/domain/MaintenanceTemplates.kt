package com.autolog.app.domain

enum class FuelType(val label: String) { PETROL("Petrol"), DIESEL("Diesel"), HYBRID("Hybrid") }

data class TemplateItem(val name: String, val intervalKm: Int?, val intervalMonths: Int?)

/**
 * Generic starting intervals applied when a vehicle is added.
 * Edit them per vehicle to match the manufacturer's service manual;
 * severe conditions (dust, heat, short trips) usually warrant shorter intervals.
 */
object MaintenanceTemplates {
    private val common = listOf(
        TemplateItem("Engine oil", 10_000, 12),
        TemplateItem("Oil filter", 10_000, 12),
        TemplateItem("Air filter", 20_000, 24),
        TemplateItem("Cabin filter", 15_000, 12),
        TemplateItem("Tyre rotation", 10_000, 6),
        TemplateItem("Tyres", 50_000, 60),
        TemplateItem("Brake pads (inspect)", 20_000, 12),
        TemplateItem("Brake fluid", null, 24),
        TemplateItem("Coolant", 40_000, 24),
        TemplateItem("Battery", null, 36),
        TemplateItem("Wiper blades", null, 12),
        TemplateItem("Insurance renewal", null, 12),
    )

    fun forType(type: FuelType): List<TemplateItem> = when (type) {
        FuelType.PETROL, FuelType.HYBRID -> common + TemplateItem("Spark plugs", 40_000, 48)
        FuelType.DIESEL -> common + TemplateItem("Fuel filter", 30_000, 24)
    }
}
