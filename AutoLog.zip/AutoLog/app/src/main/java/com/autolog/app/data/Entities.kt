package com.autolog.app.data

import androidx.room.*
import com.autolog.app.domain.FuelType
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val make: String,
    val model: String,
    val year: Int?,
    val plate: String,
    val fuelType: FuelType,
    val tankLitres: Double,
    val initialOdometer: Double,
    val createdOn: LocalDate,
)

@Entity(
    tableName = "fuel_entries",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("vehicleId")],
)
data class FuelEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val date: LocalDate,
    val odometer: Double,
    val litres: Double,
    val pricePerLitre: Double,
    val totalCost: Double,
    val isFull: Boolean,
    val station: String = "",
    val note: String = "",
)

@Entity(
    tableName = "maintenance_items",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("vehicleId")],
)
data class MaintenanceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val name: String,
    val intervalKm: Int?,
    val intervalMonths: Int?,
    val lastDoneDate: LocalDate,
    val lastDoneOdometer: Double,
)

@Entity(
    tableName = "service_records",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("vehicleId")],
)
data class ServiceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val itemName: String,
    val date: LocalDate,
    val odometer: Double,
    val cost: Double,
    val note: String = "",
)

class Converters {
    @TypeConverter fun fromDate(d: LocalDate?): Long? = d?.toEpochDay()
    @TypeConverter fun toDate(v: Long?): LocalDate? = v?.let(LocalDate::ofEpochDay)
    @TypeConverter fun fromFuel(t: FuelType): String = t.name
    @TypeConverter fun toFuel(v: String): FuelType = FuelType.valueOf(v)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles ORDER BY name") fun observeAll(): Flow<List<Vehicle>>
    @Query("SELECT * FROM vehicles ORDER BY name") suspend fun all(): List<Vehicle>
    @Insert suspend fun insert(v: Vehicle): Long
    @Update suspend fun update(v: Vehicle)
    @Delete suspend fun delete(v: Vehicle)
    @Insert suspend fun insertAll(v: List<Vehicle>)
    @Query("DELETE FROM vehicles") suspend fun deleteAll()
}

@Dao
interface FuelDao {
    @Query("SELECT * FROM fuel_entries WHERE vehicleId = :vid ORDER BY odometer DESC")
    fun observe(vid: Long): Flow<List<FuelEntry>>
    @Query("SELECT * FROM fuel_entries WHERE vehicleId = :vid ORDER BY odometer")
    suspend fun forVehicle(vid: Long): List<FuelEntry>
    @Query("SELECT MAX(odometer) FROM fuel_entries WHERE vehicleId = :vid")
    suspend fun maxOdometer(vid: Long): Double?
    @Insert suspend fun insert(e: FuelEntry): Long
    @Delete suspend fun delete(e: FuelEntry)
    @Query("SELECT * FROM fuel_entries ORDER BY id") suspend fun all(): List<FuelEntry>
    @Insert suspend fun insertAll(e: List<FuelEntry>)
    @Query("DELETE FROM fuel_entries") suspend fun deleteAll()
}

@Dao
abstract class MaintenanceDao {
    @Query("SELECT * FROM maintenance_items WHERE vehicleId = :vid ORDER BY name")
    abstract fun observeItems(vid: Long): Flow<List<MaintenanceItem>>
    @Query("SELECT * FROM maintenance_items WHERE vehicleId = :vid ORDER BY name")
    abstract suspend fun items(vid: Long): List<MaintenanceItem>
    @Insert abstract suspend fun insertItems(items: List<MaintenanceItem>)
    @Insert abstract suspend fun insertItem(item: MaintenanceItem): Long
    @Update abstract suspend fun updateItem(item: MaintenanceItem)
    @Delete abstract suspend fun deleteItem(item: MaintenanceItem)

    @Query("SELECT * FROM service_records WHERE vehicleId = :vid ORDER BY date DESC")
    abstract fun observeRecords(vid: Long): Flow<List<ServiceRecord>>
    @Query("SELECT * FROM service_records WHERE vehicleId = :vid ORDER BY date")
    abstract suspend fun records(vid: Long): List<ServiceRecord>
    @Query("SELECT MAX(odometer) FROM service_records WHERE vehicleId = :vid")
    abstract suspend fun maxOdometer(vid: Long): Double?
    @Insert abstract suspend fun insertRecord(r: ServiceRecord): Long

    @Query("SELECT * FROM maintenance_items ORDER BY id") abstract suspend fun allItems(): List<MaintenanceItem>
    @Query("SELECT * FROM service_records ORDER BY id") abstract suspend fun allRecords(): List<ServiceRecord>
    @Insert abstract suspend fun insertRecords(r: List<ServiceRecord>)
    @Query("DELETE FROM maintenance_items") abstract suspend fun deleteAllItems()
    @Query("DELETE FROM service_records") abstract suspend fun deleteAllRecords()

    @Transaction
    open suspend fun markDone(item: MaintenanceItem, record: ServiceRecord) {
        insertRecord(record)
        updateItem(item.copy(lastDoneDate = record.date, lastDoneOdometer = record.odometer))
    }
}
