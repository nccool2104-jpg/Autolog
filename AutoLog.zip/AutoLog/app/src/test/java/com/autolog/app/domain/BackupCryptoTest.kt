package com.autolog.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupCryptoTest {
    private val pw = "correct horse battery".toCharArray()
    private val data = """{"vehicles":[{"name":"Daily car"}]}""".toByteArray()
    private val fast = 100_000 // keeps tests quick; production uses BackupCrypto.ITERATIONS
    private val rk = BackupCrypto.newRecoveryKey()

    private fun blob() = BackupCrypto.encrypt(data, pw.copyOf(), rk.publicKey, fast)
    private fun fails(block: () -> Unit): String =
        try { block(); throw AssertionError("expected BackupException") } catch (e: BackupException) { e.message!! }

    @Test fun opensWithPassword() = assertEquals(String(data), String(BackupCrypto.decryptWithPassword(blob(), pw.copyOf())))

    @Test fun opensWithRecoveryCode() = assertEquals(String(data), String(BackupCrypto.decryptWithRecovery(blob(), rk.code)))

    @Test fun recoveryCodeIsForgiving() {
        val messy = rk.code.lowercase().replace("-", " ").replace('0', 'o')
        assertEquals(String(data), String(BackupCrypto.decryptWithRecovery(blob(), messy)))
    }

    @Test fun recoveryCodeFormat() {
        assertEquals(14, rk.code.split("-").size)
        assertTrue(rk.code.split("-").all { it.length == 4 })
    }

    @Test fun typoInRecoveryCodeCaughtByChecksum() {
        val c = rk.code.toCharArray(); c[0] = if (c[0] == 'A') 'B' else 'A'
        assertEquals("Recovery code is incorrect. Check for typos.", fails { BackupCrypto.decryptWithRecovery(blob(), String(c)) })
    }

    @Test fun otherRecoveryCodeRejected() {
        val other = BackupCrypto.newRecoveryKey()
        assertTrue(fails { BackupCrypto.decryptWithRecovery(blob(), other.code) }.startsWith("Wrong password or recovery code"))
    }

    @Test fun recoveryMatchesOnlyOwnKey() {
        assertTrue(BackupCrypto.recoveryMatches(rk.code, rk.publicKey))
        assertTrue(!BackupCrypto.recoveryMatches(BackupCrypto.newRecoveryKey().code, rk.publicKey))
        assertTrue(!BackupCrypto.recoveryMatches("not a code", rk.publicKey))
    }

    @Test fun wrongPasswordRejected() {
        assertTrue(fails { BackupCrypto.decryptWithPassword(blob(), "wrong password!".toCharArray()) }.startsWith("Wrong password"))
    }

    @Test fun tamperedContentRejected() {
        val b = blob(); b[b.size - 20] = (b[b.size - 20].toInt() xor 1).toByte()
        assertEquals("The file has been modified or damaged", fails { BackupCrypto.decryptWithPassword(b, pw.copyOf()) })
    }

    @Test fun tamperedRecoverySlotDetected() {
        val b = blob(); b[b.size - 70] = (b[b.size - 70].toInt() xor 1).toByte() // inside header, after password slot
        fails { BackupCrypto.decryptWithPassword(b, pw.copyOf()) } // header is AAD for content
    }

    @Test fun craftedIterationCountRejected() {
        val b = blob(); b[5] = 0x7F
        assertEquals("Backup file header is invalid", fails { BackupCrypto.decryptWithPassword(b, pw.copyOf()) })
    }

    @Test fun verifier() {
        val v = BackupCrypto.makeVerifier(pw.copyOf(), fast)
        assertTrue(BackupCrypto.checkVerifier(pw.copyOf(), v))
        assertTrue(!BackupCrypto.checkVerifier("correct horse batterz".toCharArray(), v))
    }

    @Test fun shortPasswordRefused() { fails { BackupCrypto.encrypt(data, "short".toCharArray(), rk.publicKey, fast) } }

    @Test fun garbageRejected() {
        assertEquals("Not an AutoLog backup file", fails { BackupCrypto.decryptWithPassword(ByteArray(300), pw.copyOf()) })
        assertEquals("Not an AutoLog backup file", fails { BackupCrypto.decryptWithPassword(ByteArray(10), pw.copyOf()) })
    }
}
