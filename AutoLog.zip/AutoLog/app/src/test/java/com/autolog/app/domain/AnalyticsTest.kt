package com.autolog.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class AnalyticsTest {
    private val d0 = LocalDate.of(2026, 1, 1)

    private val fills = listOf(
        FuelFill(d0, 10_000.0, 40.0, 2400.0, true),             // baseline full
        FuelFill(d0.plusDays(5), 10_250.0, 10.0, 600.0, false), // partial
        FuelFill(d0.plusDays(10), 10_500.0, 25.0, 1500.0, true),// 35 L / 500 km = 7.0
        FuelFill(d0.plusDays(20), 11_000.0, 40.0, 2400.0, true),// 40 L / 500 km = 8.0
    )

    @Test fun fullToFull_absorbsPartials() {
        val s = Analytics.segments(fills)
        assertEquals(2, s.size)
        assertEquals(7.0, s[0].lPer100, 1e-9)
        assertEquals(8.0, s[1].lPer100, 1e-9)
    }

    @Test fun distanceWeightedAverage() {
        assertEquals(0.075, Analytics.litresPerKm(Analytics.segments(fills))!!, 1e-9)
    }

    @Test fun dailyKm_ewma() {
        val r = listOf(OdoReading(d0, 0.0), OdoReading(d0.plusDays(10), 500.0), OdoReading(d0.plusDays(20), 1500.0))
        // 50 then 100 km/day: 0.3*100 + 0.7*50 = 65
        assertEquals(65.0, Analytics.dailyKm(r)!!, 1e-9)
        assertNull(Analytics.dailyKm(r.take(1)))
    }

    @Test fun forecast_refill() {
        // 50 L tank, 300 km since full at 0.08 L/km -> 26 L left; reserve 5 L -> 21 L usable -> 262.5 km -> 5 days at 50/day
        val f = Analytics.forecast(
            listOf(FuelFill(d0, 1000.0, 50.0, 0.0, true)), 50.0, 0.08, 50.0, 1300.0, d0.plusDays(6),
        )!!
        assertEquals(26.0, f.fuelLeftL, 1e-9)
        assertEquals(5L, f.daysToRefill)
        assertEquals(d0.plusDays(11), f.refillDate)
    }

    @Test fun maintenance_firstTriggerWins() {
        val rule = MaintenanceRule(1, "Oil", 10_000, 12, d0, 20_000.0)
        // 2,000 km left at 100 km/day = 20 days, well before the 12-month limit
        val due = Analytics.maintenanceDue(rule, 28_000.0, 100.0, d0.plusDays(30))
        assertEquals(d0.plusDays(50), due.dueDate)
        assertEquals(DueStatus.DUE_SOON, due.status)
        val over = Analytics.maintenanceDue(rule, 30_500.0, 100.0, d0.plusDays(30))
        assertEquals(DueStatus.OVERDUE, over.status)
    }

    @Test fun consumptionAlert_flagsSpike() {
        val segs = listOf(7.0, 7.0, 7.0, 9.0).mapIndexed { i, l -> Segment(d0.plusDays(i.toLong()), 100.0, l) }
        val a = Analytics.consumptionAlert(segs)
        assertNotNull(a)
        assertEquals(28.57, a!!.deviationPct, 0.01)
        assertNull(Analytics.consumptionAlert(segs.take(3)))
    }
}
